title: Gitea 仓库rss订阅生成
date: '2020-04-21 14:06:27'
updated: '2020-11-01 18:19:04'
tags: [git, python, 原创]
permalink: /articles/2020/04/21/1587449187524.html
---
![mmexport1582213605407.jpg](https://img.zeekling.cn/images/2020/02/23/mmexport1582213605407.jpg)

## 简介

本人使用Gitea 搭建了私人仓库，并且在[个站商店](https://storeweb.cn/site/one/971) 上面添加了自己的仓库，但是Gitea没有提供站点地图和rss订阅相关功能，于是自己就写了脚本来做这件事，站点地图的详见[根据站点生成sitemap.xml的脚本](https://www.zeekling.cn/articles/2020/03/22/1584855312392.html) 。

本文就是处理rss订阅的脚本。

## 使用

- 安装依赖

  ```sh
  pip3 install -r requirement.txt
  ```
- 打开gen_rss.py 修改

  ```python
  # 需要保存的rss位置
  file_path = "./rss.xml"
  # 自己gitea的url
  code_url='https://git.zeekling.cn/'
  ```
- 执行下面脚本即可

  ```bash
  ./gen_rss.py
  ```
- 添加定时

```bash
*/10 * * * * cd /root/gitea-rss && ./gen_rss.py
```
