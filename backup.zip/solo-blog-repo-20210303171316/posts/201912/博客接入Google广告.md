title: 博客接入Google 广告
date: '2019-12-10 22:59:24'
updated: '2021-01-03 21:24:27'
tags: [生活, 原创]
permalink: /articles/2019/12/10/1575989964574.html
---
最近可能是闲的蛋疼，所以打算在自己博客上面接入广告，主要步骤如下：

- 注册 Google 账号，Google 账号我老早就有了。详细参见：[https://51.ruyo.net/12240.html](https://51.ruyo.net/12240.html)
- 申请 AdSense:填写网站相关信息，申请 AdSense，一般一天后就通知你成功！
- 生成一段广告代码，挂到自己的网站上！等待复核。 solo 博客配置到 HTML header 里面：![外网](https://img.zeekling.cn/images/2019/12/10/Screenshot-at-2019-12-10-22-47-08.png)
- 审核完成之后，添加自己的子域名，我添加了这么多：![](https://img.zeekling.cn/images/2019/12/10/Screenshot-at-2019-12-10-22-50-54.png)
- 新建属于自己的广告单元，我新建了下面三个，第二个没有用到。![](https://img.zeekling.cn/images/2019/12/10/Screenshot-at-2019-12-10-22-52-28.png)
- 添加广告到自己博客里面，在 solo 博客下面可以将 js 添加到 HTML header 里面，将剩余的代码贴到公告里面![](https://img.zeekling.cn/images/2019/12/10/Screenshot-at-2019-12-10-22-54-50.png)
- 刷新自己的网站就可以看到广告了(有可能会被广告拦截插件拦截掉，哎)![](https://img.zeekling.cn/images/2019/12/10/Screenshot-at-2019-12-10-22-57-24.png)

过段时间就可以在自己 AdSense 账号上面看到自己的收益了，少得可怜..
![](https://img.zeekling.cn/images/2019/12/10/Screenshot-at-2019-12-10-22-58-30.png)

后记：

因为广告影响体验，并且广告也挣不了几个钱，感觉得不偿失，于是就停掉了广告。
