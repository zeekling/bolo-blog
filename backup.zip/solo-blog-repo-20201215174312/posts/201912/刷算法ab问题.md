title: 刷算法 - a+b问题
date: '2019-12-12 00:00:27'
updated: '2020-11-21 18:12:49'
tags: [算法题, 原创]
permalink: /articles/2019/12/12/1576080027153.html
---
![78f65c5091dd306226282130c3a85105.jpg](https://img.zeekling.cn/images/2020/08/24/78f65c5091dd306226282130c3a85105.jpg)

## 问题描述

给出两个整数 a 和 b , 求他们的和。

> 显然你可以直接 return a + b，但是你是否可以挑战一下不这样做？

## 提示

两数异或得到无进位的加法，两数相与并且左移一位表示进位.

详细代码:

```java
public int plus(int a, int b){
          while(b != 0){
                    int ta = a^b;
                    int tb = (a&b)<<1;
                    a = ta;
                    b = tb;
          }
          return a;
}
```
