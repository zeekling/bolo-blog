title: bolo 编译镜像添加jvm参数
date: '2020-08-25 11:09:45'
updated: '2020-10-07 22:34:05'
tags: [原创, bolo, 博客]
permalink: /articles/2020/08/25/1598324985257.html
---
![f2cb162b827281e9e2e0d4f248c67c10.jpg](https://img.zeekling.cn/images/2020/08/23/f2cb162b827281e9e2e0d4f248c67c10.jpg)

## 起因

偶然间注意到实用功能>日志浏览>JVM空闲内存太少了，于是就看了下bolo程序的内存回收情况，发现ygc执行次数太多了，于是就有了改造dockerfile的想法。

## 编译

### 下载项目

```
git clone https://github.com/adlered/bolo-solo.git
```

### 修改dockerfile

将dockerfile 修改为如下内容

```
FROM maven:3-jdk-8-alpine as MVN_BUILD

WORKDIR /opt/bolo/
ADD . /tmp
RUN cd /tmp && mvn package -DskipTests -Pci && mv target/bolo/* /opt/bolo/ \
    && cp -f /tmp/src/main/resources/docker/* /opt/bolo/WEB-INF/classes/

FROM openjdk:8-alpine
LABEL maintainer="Liang Ding<d@b3log.org>"

WORKDIR /opt/bolo/
COPY --from=MVN_BUILD /opt/bolo/ /opt/bolo/
RUN apk add --no-cache ca-certificates tzdata

ENV TZ=Asia/Shanghai
EXPOSE 8080

ENV JAVA_OPTS="-Xms400m -Xmx400m -Xmn320m -Xloggc:/var/log/gc.log"

ENV LISTEN_PORT=8080

ENV SERVER_HOST="localhost"

ENV SERVER_SCHEME="http"

ENV SERVER_PORT=8080

ENV LUTE_HTTP="http://127.0.0.1:8249"

ENTRYPOINT  java ${JAVA_OPTS} -cp WEB-INF/lib/*:WEB-INF/classes  org.b3log.solo.Starter \
     --listen_port=${LISTEN_PORT} \
         --server_scheme=${SERVER_SCHEME} \
         --server_host=${SERVER_HOST} \
         --server_port=${SERVER_PORT} \
         --lute_http=${LUTE_HTTP}
```

### 编译

执行下面命令

```
docker build -t "zeek/bolo" .
```

### 启动

执行下面启动命令

```
docker run --detach --name bolo --network=host  \
    --env RUNTIME_DB="MYSQL" \
        --env JAVA_OPTS="-Xms300m -Xmx300m -Xmn230m -Xloggc:/var/log/gc.log" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="123456" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
        --env SERVER_HOST="www.zeekling.cn" \
        --env SERVER_PORT="443" \
        --env SERVER_SCHEME="https" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&allowPublicKeyRetrieval=true&useSSL=false&serverTimezone=UTC" \
    -v /dockerData/bolo/bolo-fantastic:/opt/bolo/skins/bolo-fantastic \
    -v /dockerData/bolo/bolo-NeoEase:/opt/bolo/skins//bolo-NeoEase-mod \
    zeek/bolo \
        --lute_http=http://127.0.0.1:8249
```

## 结束

至此，添加jvm控制参数就结束了。空闲内存明显也多了很多，如下图：

![202008251057.png](https://pan.zeekling.cn/jbN_2020-08-25_10-57.png)

gc也少了很多（内存还可以根据实际情况调整）。

![202008251108.png](https://pan.zeekling.cn/IXm_2020-08-25_11-08.png)

