title: 【Redis源码】Redis 6 ACL源码详解
date: '2020-11-22 23:49:38'
updated: '2020-11-23 00:24:29'
tags: [原创, redis, 新特性, 源码]
permalink: /articles/2020/11/22/1606060178482.html
---
![886c4fc7124ccee5c3fc696866312564.jpg](https://img.zeekling.cn/images/2020/11/22/886c4fc7124ccee5c3fc696866312564.jpg)

## 简介

本文主要是讲解Redis 6的ACL的实现原理。基本使用详见：[Redis 6.0新特性——ACLs](/articles/2020/11/22/1606048977051.html)，以及[Redis启动过程分析](https://www.zeekling.cn/articles/2020/09/25/1601041404734.html)。

## 启动初始化

### 初始化默认用户

ACL子模块在[Redis启动过程中初始化](https://www.zeekling.cn/articles/2020/09/25/1601041404734.html)，下面代码主要是初始化ACL的结构：

```cpp
/* 
 * 初始化ACL子系统
 * */
void ACLInit(void) {
    Users = raxNew(); // 初始化用户信息
    UsersToLoad = listCreate();
    ACLLog = listCreate();
    ACLInitDefaultUser();
    server.requirepass = NULL; /* Only used for backward compatibility. */
}
```

ACLInitDefaultUser函数主要是初始化默认用户，在Redis 6当中默认用户的权限就相当于操作系统的管理员一样，拥有很大的权限，要限制远程使用默认用户连接。

```cpp
/* 初始化默认用户 */
void ACLInitDefaultUser(void) {
    DefaultUser = ACLCreateUser("default",7);
    ACLSetUser(DefaultUser,"+@all",-1); // 默认用户赋予所有命令的权限
    ACLSetUser(DefaultUser,"~*",-1);// 可以操作任何key
    ACLSetUser(DefaultUser,"on",-1);// 默认开启
    ACLSetUser(DefaultUser,"nopass",-1); // 默认不需要密码
}
```

### 加载ACL用户信息

ACL数据结构初始化完成之后，通过函数 `ACLLoadUsersAtStartup`加载Redis配置里面的ACL用户信息。Redis ACL配置信息主要有两种方式：

- 在redis.conf文件中通过user 配置项配置的ACL信息。比如：`user worker +@list +@connection ~jobs:* on >ffa9203c493aa99`
- 在`redis.conf`中配置`aclfile`所配置的文件中。格式如下图所示：

![图片](https://pan.zeekling.cn/fWh_image.png)

#### 通过user方式

#### 通过文件方式

正在看阅读源码
