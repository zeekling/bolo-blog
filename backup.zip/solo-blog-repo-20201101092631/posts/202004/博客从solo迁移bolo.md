title: 博客从solo迁移bolo
date: '2020-04-26 14:54:01'
updated: '2020-04-27 23:18:23'
tags: [原创, 黑客派]
permalink: /articles/2019/09/07/1587898561235.html
---

## solo 和bolo 简介

### solo
Solo is a small and beautiful open source blog system, designed for programmers. Solo has a very active community, which can push articles as posts to the community, and replies from the community will be linked as blog comments (for details, please visit B3log Ideas - Distributed Community Network).

## bolo
菠萝博客：专为程序员设计的Java博客系统 | 极简安装 | guitar基于Solo | 精致主题 | 动态邮件提醒 | 自定义图床 | 离线博客 | 本地登录 | 免登录评论 | 文章同步/备份到黑客派 | package WAR包、Tomcat、Docker、JAR部署支持 | bookmark 独立分类功能 | truck 轻松迁移于Bolo/Solo之间

## 原因

solo 博客使用了大概有一年的时间，总体感觉上还不错，但是从在一些其他方面的问题，就是和[黑客派](https://hacpai.com/) 绑定的太死了，有时候会因为社区的原因导致博客的访问量不准确，以及同一ip访问次数过频繁的时候会导致博客访问不了。

bolo博客是从solo博客上面重新开发出来的，没有solo博客存在的弊端，所以切换成了solo。

