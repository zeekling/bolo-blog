title: idea卡顿且报错：UI was frozen for xxxxx ms问题解决
date: '2021-04-30 01:05:15'
updated: '2021-04-30 19:13:06'
tags: [idea, Java, 卡顿]
permalink: /articles/2021/04/30/1619715915118.html
---
![images](https://img.zeekling.cn/images/2020/10/08/7aa70994fec9d0914a9021285a457184.md.jpg)

## 现象

idea 启动并且点击某个菜单之后一点反应也没有，点击关闭也关闭不掉，查看日志报错如下：

```bash
➜  bin 2021-04-30 00:20:31,777 [ 317987]   WARN - .diagnostic.PerformanceWatcher - UI was frozen for 5750ms, details saved to /home/zeek/.cache/JetBrains/IntelliJIdea2020.3/log/threadDumps-freeze-20210430-002031-IU-203.7148.57-RandomAccessFile.readBytes-5sec 
2021-04-30 00:20:45,194 [ 331404]   WARN - s.ui.configuration.SdkDetector - No version is returned for detected SDK IDEA JDK at /home/zeek/software/idea-IU-203.7148.57 
2021-04-30 00:22:05,304 [ 411514]   WARN - ystem.impl.ActionPopupMenuImpl - 1174ms to fill popup menu ProjectViewPopup 
2021-04-30 00:22:33,250 [ 439460]   WARN - ConfigurableExtensionPointUtil - ignore deprecated groupId: language for id: preferences.language.Kotlin.scripting 
2021-04-30 00:22:33,426 [ 439636]   WARN - ConfigurableExtensionPointUtil - use other group instead of unexpected one: build.android 
2021-04-30 00:22:44,580 [ 450790]   WARN - .diagnostic.PerformanceWatcher - UI was frozen for 12256ms, details saved to /home/zeek/.cache/JetBrains/IntelliJIdea2020.3/log/threadDumps-freeze-20210430-002237-IU-203.7148.57-ShowSettingsAction.perform-12sec
```

在最开始的时候就比较严重，具体原因也不知道是啥。

## 处理步骤

首先因为我用的是LInux操作系统，jdk默认安装的是openjdk 11,一般来讲openjdk没有oracle jdk稳定，并且openjdk 11 太新了，于是九江操作系统的默认jdk换成了oracle jdk 9版本。

```bash
➜  bin java -version
Picked up _JAVA_OPTIONS: -Dawt.useSystemAAFontSettings=on -Dswing.aatext=true
java version "9.0.1"
Java(TM) SE Runtime Environment (build 9.0.1+11)
Java HotSpot(TM) 64-Bit Server VM (build 9.0.1+11, mixed mode)
```

其次，由于idea 默认给程序使用的内存是700m左右，内存不足也可能导致idea 出现上面情况。于是将idea的运行内存调整为2G，配置文件为`idea安装目录/bin/idea64.vmoptions`，配置内容如下(只修改了-Xms 和-Xmx的大小)：

```bash
-Xms512m
-Xmx2048m
-XX:ReservedCodeCacheSize=512m
-XX:+UseConcMarkSweepGC
-XX:SoftRefLRUPolicyMSPerMB=50
-XX:CICompilerCount=2
-XX:+HeapDumpOnOutOfMemoryError
-XX:-OmitStackTraceInFastThrow
-ea
-Dsun.io.useCanonCaches=false
-Djdk.http.auth.tunneling.disabledSchemes=""
-Djdk.attach.allowAttachSelf=true
-Djdk.module.illegalAccess.silent=true
-Dkotlinx.coroutines.debug=off
-Dsun.tools.attach.tmp.only=true
```

最后在禁用掉自己平时用不到的一些插件。

经过上面三个步骤之后，idea卡顿的现象就不是那么明显了（肉眼不可见）。
