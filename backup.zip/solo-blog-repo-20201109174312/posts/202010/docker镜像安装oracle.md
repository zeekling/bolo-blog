title: docker镜像安装oracle
date: '2020-10-29 00:36:24'
updated: '2020-10-29 00:36:24'
tags: [原创, oracle, csdn, linux]
permalink: /articles/2020/10/29/1603902984323.html
---
![5a0bfd49d44555d877b1b0a6bff7387e.jpg](https://img.zeekling.cn/images/2020/09/26/5a0bfd49d44555d877b1b0a6bff7387e.jpg)

## 简介

在 `debian`中安装 `docker`，并且在 `docker`环境下使用 `oracle`。 

### docker安装

在 `https://docs.docker.com/engine/installation/#desktop`
或者去 `https://download.docker.com/linux/static/stable`网址里面下载，下载完了解压到 `/usr/bin/`下面(或者解压到其他地方，然后将解压路径添加到 `PATH`里面)即可,在 `~/.zshrc`中添加

```sh
alias docker="sudo docker" # 不想每次都输入sudo,也不想切换到root用户
# alias dockerd="sudo docker" # 在非root下面执行dockerd &可能不会生效
```

#### 注意

如果你的根目录所在的分区空间不是特别大的话，我并不建议解压到 `/usr/bin/`下面。可以解压到其他位置(docker_path),将 `docker_path`添加到 `PATH`:

```sh
vi ~/.zshrc
# 或者打开
# vi ~/.bashrc
# 在~/.zshrc 或者~/.bashrc中添加下面语句
export $DOCKER_PATH="docker_path"
export $PATH=$PATH:$DOCKER_PATH
```

### 安装 启动oracle

1. 安装启动
   * 标准版安装
     ```sh
      dockerd &
      docker pull sath89/oracle-12c  # 12c
      docker pull sath89/oracle-xe-11g # 11g
      docker pull chameleon82/oracle-xe-10g # 10g
      docker run -h "oracle12c" --name "oracle12c" -d -p 49160:22 -p 49161:1521 -p 49162:8080 \
      sath89/oracle-12c
      docker run -h "oracle11g" --name "oracle11g" -d -p 49163:22 -p 49164:1521 -p 49165:8080 \
      sath89/oracle-xe-11g
      docker run -h "oracle10g" --name "oracle10g" -d -p 49166:22 -p 49167:1521 -p 49168:8080 \
      chameleon82/oracle-xe-10g
     ```
   * 企业版安装
     下载企业版oracle,克隆项目[https://github.com/oracle/docker-images ](https://github.com/oracle/docker-images) 到本地，将oracle拷贝到在`OracleDatabase/dockerfiles/<version>`下面,执行
     ```sh
     sudo ./buildDockerImage.sh -v 12.2.0.1 -e
     docker run -h "oracle12c-ee" --name "oracle12c-ee" -d -p 49170:22 -p 49171:1521 \
     -p 49172:5500 -p 49173:8080 -e ORACLE_SID=orcl -e ORACLE_PDB=pdb -e ORACLE_PWD=zeekling \
     oracle/database:12.2.0.1-ee
     ```

     * 重新打开oracle容器

     ```sh
        docker restart oracle12c
     ```

     * tip`docker run`是new 一个新的容器出来，名字是不能重复的
2. 查看oracle启动日志

```sh
 docker logs -f oracle12c
```

3. 进入镜像的bash

```sh
 docker exec -it oracle12c /bin/bash
```

默认登进去是 `root`用户,`oracle`安装在 `oracle`用户下面,所以进去是要切换用户的；切换用户时，默认不需要密码。
4. 查看docker容器ip

```sh
 docker inspect oracle12c  | grep IPAddress
```

5. 连接数据库
   切换到oracle用户，在`~/.bashrc`里面添加

```sh
export ORACLE_HOME=/u01/app/oracle/product/12.1.0/xe
export PATH=$PATH:$ORACLE_HOME/bin
export $ORACLE_SID=xe
```

这样就不用切换到 `oracle`的 `bin`目录下面执行 `sqlplus / as sysdba`了

6. 图形化界面安装和启动
   在`root`用户下执行

```sh
curl -s https://shipyard-project.com/deploy | bash -s
```

在浏览器中打开[http://127.0.0.1:8080](http://127.0.0.1:8080),输入用户名/密码:`admin/shipyard`
再次启动 `docker` 时，图形界面会随着容器启动，不用用命令启动
可以将 `https://shipyard-project.com/deploy`中的脚本保存下来，下次安装的时候使用

```sh
curl https://shipyard-project.com/deploy > /usr/bin/dockerdeploy
# 下次执行下面语句
dockerd &
su root
dockerdeploy
```

7. 安装`oracle`客户端
   在[http://www.oracle.com/technetwork/database/features/instant-client/index-097480.html ](http://www.oracle.com/technetwork/database/features/instant-client/index-097480.html)
   下载oracle客户端，建议下载rpm包，在debian系列linux上可以转成deb包，下载下面几个包就行了

```sh
-rw-r--r-- 1 root root  42M Dec 14 22:22 oracle-instantclient12.2-basic_12.2.0.1.0-2_amd64.deb
-rw-r--r-- 1 root root 551K Dec 14 22:22 oracle-instantclient12.2-devel_12.2.0.1.0-2_amd64.deb
-rw-r--r-- 1 root root 1.5M Dec 14 22:22 oracle-instantclient12.2-jdbc_12.2.0.1.0-2_amd64.deb
-rw-r--r-- 1 root root 633K Dec 14 22:23 oracle-instantclient12.2-sqlplus_12.2.0.1.0-2_amd64.deb
-rw-r--r-- 1 root root 795K Dec 14 23:17 oracle-instantclient12.2-tools_12.2.0.1.0-2_amd64.deb
```

安装完了之后在 `~/.zshrc`或者 `~/.bashrc`或者 `/etc/profile`(第三个需要重启电脑)中添加

```sh
# oracle
export ORACLE_HOME=/usr/lib/oracle/12.2/client64
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$ORACLE_HOME/lib
export TNS_ADMIN=$ORACLE_HOME
export PATH=$ORACLE_HOME/bin:$PATH
```

在 `/usr/lib/oracle/12.2/client64/`下新建文件 `tnsnames.ora`添加

```sql
xe=
  (DESCRIPTION =
   (ADDRESS_LIST =
    (ADDRESS = (PROTOCOL = TCP)(HOST = localhost)(PORT = 49161))
   )
   (CONNECT_DATA =
      (SERVICE_NAME = xe)
   )
  )
```

然后在终端中输入(需要新键用户等操作)

```sh
sqlplus eoda/foo@xe
```

就可以了
