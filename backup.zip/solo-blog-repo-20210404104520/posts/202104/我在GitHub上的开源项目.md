title: 我在 GitHub 上的开源项目
date: '2021-04-02 21:39:18'
updated: '2021-04-02 21:39:18'
tags: [开源, GitHub]
permalink: /github
---
![GitHub Repo](images/github_repo.jpg)

### 1. [WebStack-Guns](https://github.com/zeekling/WebStack-Guns) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`2`](https://github.com/zeekling/WebStack-Guns/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zeekling/WebStack-Guns/network/members "分叉数")</span>

一个开源的网址导航网站项目，后台基于Guns和Springboot



---

### 2. [bolo-blog](https://github.com/zeekling/bolo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/zeekling/bolo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zeekling/bolo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.zeekling.cn`](https://www.zeekling.cn "项目主页")</span>

✍️ 小令童鞋 - 梅干菜你个小酥饼哦。



---

### 3. [bolo-fantastic](https://github.com/zeekling/bolo-fantastic) <kbd title="主要编程语言">FreeMarker</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/zeekling/bolo-fantastic/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zeekling/bolo-fantastic/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.zeekling.cn/`](https://www.zeekling.cn/ "项目主页")</span>

迁移到bolo 博客，保存自己自定义的皮肤部分。



---

### 4. [bolo-solo](https://github.com/zeekling/bolo-solo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/zeekling/bolo-solo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zeekling/bolo-solo/network/members "分叉数")&nbsp;&nbsp;[🏠`https://demo.stackoverflow.wiki`](https://demo.stackoverflow.wiki "项目主页")</span>

🍍菠萝博客：专为程序员设计的Java博客系统 | 极简安装 | 🎸基于Solo | 精致主题 | 动态邮件提醒 | 自定义图床 | 离线博客 | 本地登录 | 免登录评论 | 文章同步/备份到黑客派 | :package: WAR包、Tomcat、Docker、JAR部署支持 | :bookmark: 独立分类功能 | :truck: 轻松迁移于Bolo/Solo之间



---

### 5. [redis_study](https://github.com/zeekling/redis_study) <kbd title="主要编程语言">C</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/zeekling/redis_study/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/zeekling/redis_study/network/members "分叉数")&nbsp;&nbsp;[🏠`https://git.zeekling.cn/zeekling/redis`](https://git.zeekling.cn/zeekling/redis "项目主页")</span>

Redis是一个内存中的数据库，它保存在磁盘上。数据模型是键值，但支持多种不同类型的值：字符串、列表、集合、排序集、哈希、流、HyperLogLogs、位图。



---

### 6. [zeekling](https://github.com/zeekling/zeekling) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/zeekling/zeekling/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/zeekling/zeekling/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www/zeekling.cn`](https://www/zeekling.cn "项目主页")</span>

Stay simple, stay naive.



---

### 7. [dockerFiles](https://github.com/zeekling/dockerFiles) <kbd title="主要编程语言">Dockerfile</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/zeekling/dockerFiles/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zeekling/dockerFiles/network/members "分叉数")</span>





---

### 8. [gitea-rss](https://github.com/zeekling/gitea-rss) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/zeekling/gitea-rss/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zeekling/gitea-rss/network/members "分叉数")&nbsp;&nbsp;[🏠`https://git.zeekling.cn/python/gitea-rss`](https://git.zeekling.cn/python/gitea-rss "项目主页")</span>

生成rss总的rss的代码。



---

### 9. [github_zeekling](https://github.com/zeekling/github_zeekling) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/zeekling/github_zeekling/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zeekling/github_zeekling/network/members "分叉数")&nbsp;&nbsp;[🏠`https://git.zeekling.cn/zeekling/github_zeekling`](https://git.zeekling.cn/zeekling/github_zeekling "项目主页")</span>

自动跟新博客信息到github



---

### 10. [leetCode](https://github.com/zeekling/leetCode) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/zeekling/leetCode/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zeekling/leetCode/network/members "分叉数")</span>

leetCode刷题



---

### 11. [note](https://github.com/zeekling/note) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/zeekling/note/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zeekling/note/network/members "分叉数")</span>

笔记



---

### 12. [script](https://github.com/zeekling/script) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/zeekling/script/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/zeekling/script/network/members "分叉数")</span>

linux 相关的脚本.

