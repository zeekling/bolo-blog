title: Gogs迁移Gitea
date: '2020-02-23 23:04:10'
updated: '2020-11-01 18:13:55'
tags: [git, 原创]
permalink: /articles/2020/02/23/1582470250287.html
---
![8b09a688cb2102fbba58cd43675c0b76.jpg](https://img.zeekling.cn/images/2020/10/06/8b09a688cb2102fbba58cd43675c0b76.jpg)

## 迁移原因

- Gogs 更新功能比 Gitea 少很多，虽然不一定用得到。
- Gitea 更新快，一些 bug 解决的快一点(虽然我没发现什么 bug)
- 可能是因为我 Gogs 用的时间久了，出现了视觉疲劳？

## 迁移过程

- 备份原来的项目，项目不多全部克隆了下来。
- 安装 MySQL 镜像

```sh
docker pull mysql
docker stop mysql
docker rm mysql
# /dockerData/mysql地址不存在可以执行下面语句
# mkdir -p /dockerData/mysql 
docker run -d --name=mysql -m 500m\
        --env=MYSQL_ROOT_PASSWORD=123456 \
        -p 3306:3306 \
        -v /dockerData/mysql:/var/lib/mysql \
        mysql --default-authentication-plugin=mysql_native_password
```

- 新建数据库：gitea 以及新建文件夹`/dockerData/gitea`
- 安装 gitea

```sh
## 自己写的重启脚本,mysql是之前已经新建好的
gitea_version="1.13.0-rc1"
docker pull gitea/gitea:${gitea_version}
docker stop gitea
docker rm gitea
docker run -d --name=gitea  \
        -p 222:22 -p 3003:3000 \
        --link mysql:mysql \
        --link redis:redis \
        -v /dockerData/gitea:/data \
        -v /dockerData/gitea/gitea/:/var/lib/gitea/custom \
        -v /dockerData/gitea/gitea/conf:/etc/gitea/ \
        gitea/gitea:${gitea_version}
```

- nginx 配置

```nginx
server {
        listen 80 ;
        listen [::]:80;

        listen 443 ssl http2;
        listen [::]:443 ssl http2;
        ssl_certificate /etc/nginx/cert/git.crt;
        ssl_certificate_key /etc/nginx/cert/git.key;

        root /var/www/html;
        client_max_body_size 50M;

        index index.html index.htm index.nginx-debian.html;

        server_name git.zeekling.cn;

        if ( $scheme = http  ){
                return 301 https://$server_name$request_uri;
        }
        location / {
                add_header Strict-Transport-Security "max-age=31536000";
                proxy_pass http://127.0.0.1:3003;
                proxy_set_header  X-Real-IP  $remote_addr;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;
                proxy_set_header Upgrade $http_upgrade;
        }

        location ~ .(jpg|png|gif|css|js|pdf|scss|ico|jpeg|bmp|flv|mp4|mp3|swf|wma|wmv|asf|mmf|zip|rar|gz)$ {
                proxy_pass http://127.0.0.1:3003;
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;
                proxy_set_header Upgrade $http_upgrade;
                proxy_set_header Connection "upgrade";
                proxy_cache cache_one;
                proxy_cache_valid 200 302 30d;
                proxy_cache_valid 301 30d;
                proxy_cache_valid any 30d;
                expires 30d;
                proxy_redirect off;
                add_header wall "Stay simple, stay naive.";
        }

        location /ads.txt {
                autoindex on;
        }
}
```

- 重启 Gitea 服务：

```
docker restart gitea
```

- 上传自己的项目(我用的 Gogs 版本太新了，不能直接迁移。),迁移的时候好像丢了一个用户的数据(wangchao 用户的数据)
