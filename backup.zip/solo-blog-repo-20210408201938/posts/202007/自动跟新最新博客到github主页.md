title: 自动跟新最新博客到github主页
date: '2020-07-26 22:26:31'
updated: '2020-10-07 22:43:45'
tags: [Java, 博客, 原创]
permalink: /articles/2020/07/26/1595773591724.html
---
![221543-1576419343705c.jpg](https://img.zeekling.cn/images/2020/01/18/221543-1576419343705c.jpg)

## 简介

最近github可以显示类似于主页的东西了，所以打算将自己最新的博客推送到github主页。

我的github主页:[zeekling](https://github.com/zeekling)

## 项目

代码项目位置为：[https://git.zeekling.cn/zeekling/github_zeekling](https://git.zeekling.cn/zeekling/github_zeekling)

编译项目：

```
git clone ssh://git@git.zeekling.cn:222/zeekling/github_zeekling.git
cd github_zeekling
./build.sh
```

修改配置：

```
# 博客名字
blog.title=小令童鞋
# 二级标题
blog.subTitle=梅干菜你个小酥饼哦。
# 主页
blog.home=https://www/zeekling.cn
# rss
blog.rss=https://www.zeekling.cn/rss.xml
# 博客图标
blog.favicon=https://img.zeekling.cn/images/2020/02/23/logo.th.png
# github token
github.pat=068783457fa6e084aad1342ed2730f33a0255b97
# 项目名字。就是自己用户名
github.repoName=zeekling
```

token 生成,如下图所示：

![202007262224.png](https://pan.zeekling.cn/GkIPXJU2Ez)

运行项目

```
cd build
./start.sh
```

