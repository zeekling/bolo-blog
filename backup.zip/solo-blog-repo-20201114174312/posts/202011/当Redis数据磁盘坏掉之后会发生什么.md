title: 当Redis数据磁盘坏掉之后会发生什么
date: '2020-11-09 23:57:42'
updated: '2020-11-13 19:38:16'
tags: [redis, 原创, 故障迁移]
permalink: /articles/2020/11/09/1604937462651.html
---
![mmexport1582213502785.jpg](https://img.zeekling.cn/images/2020/02/23/mmexport1582213502785.jpg)

## 问题简介

当Redis cluster集群数据所在磁盘的RAID卡坏掉了之后会发生什么？集群会不会进行故障迁移，以及怎么快速恢复。

## 问题1：cluster集群会进行故障迁移嘛

答案：不会。

原因：当Redis集群数据磁盘所在的RAID卡坏掉之后，Redis实例并不会因为磁盘故障而直接挂掉，所以集群会认为当前的实例并没有用故障，所以不会进行故障迁移。

## 问题2：磁盘坏掉会影响业务嘛。

答案：当 `stop-writes-on-bgsave-error`配置为yes时会的。

原因：当 `stop-writes-on-bgsave-error`配置为yes时，rdb持久化异常时会直接报错，导致数据写入时会报错，影响业务，但是不会影响到数据的读。

## 问题3：怎么快速恢复？

首先要做的就是将主实例 `stop-writes-on-bgsave-error`设置为no，这样就能保证数据正常写入集群，此时主实例之九华rdb异常，但从实例会将rdb文件持久化到磁盘里面，不会导致数据丢失。

第二步，停止业务。

第三步：停止故障主实例，等到集群故障迁移完成之后，将业务恢复。

第四步，修复RAID磁盘。

第五步，启动Redis故障主实例。
