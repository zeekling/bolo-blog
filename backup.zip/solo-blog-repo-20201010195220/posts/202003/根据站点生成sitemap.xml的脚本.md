title: 根据站点生成sitemap.xml的脚本
date: '2020-03-22 13:35:12'
updated: '2020-03-22 13:35:12'
tags: [python, sitemap, 原创]
permalink: /articles/2020/03/22/1584855312392.html
---
## 简介

本人远程服务器上面除了搭建[博客](https://www.zeekling.cn/ "ZEEKLING")之外，还搭建了[Gitea私人代码仓库](https://git.zeekling.cn/zeekling)和[图床](https://img.zeekling.cn/)服务，但是两个服务上面都没有自带 `sitemap.xml`，不方便搜索引擎收录对应的链接。于是乎自己写了个脚本用来自动生成 `sitemap.xml`

## 使用

项目地址：https://git.zeekling.cn/python/sitemap

- 安装依赖

```sh
pip3 install -r requirement.txt
```

- 修改相关参数，下面是我自己使用的一个，供参考：

```
修改get_url.py
```

```py
# 当前域名的http链接
url_root = 'https://git.zeekling.cn'
# 需要抓取的根链接，可以多写几个
url_mine_list = [
    'https://git.zeekling.cn/',
    'https://git.zeekling.cn/zeekling'
]
# 抓取的最大栈深度，默认为2,如果网站比较大的话不建议设置太大，可以在url_mine_list多设置url
max_depth = 2
# 不需要写进sitemap.xml的链接
url_robot_arr = [
    '/user/sign_up',
    '/user/login',
    '/user/forgot_password'
]
```

修改sitemap.xml位置,sitemap.py

```py
# 第一个参数为sitemap.xml的位置
create_xml('sitemap.xml', get_url.url_res_final)
```

- 执行脚本

```sh
./sitemap.py
```

执行完成之后就会生成 `sitemap.xml`

当然为了更新的快一点可以加入到定时任务里面：

```sh
0 */6 * * * cd /root/git-sitemap && ./sitemap.py
```

- 修改nginx配置，让搜索引擎能够访问得到即可。
