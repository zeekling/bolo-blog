title: 博客接入又拍云cdn
date: '2020-06-07 17:08:26'
updated: '2020-10-07 22:44:37'
tags: [原创, 博客]
permalink: /articles/2020/06/07/1591520906274.html
---
![017ebe6cfb399c9220c4b8122fc4d99f.jpg](https://img.zeekling.cn/images/2020/07/23/017ebe6cfb399c9220c4b8122fc4d99f.jpg)

## 简介

由于本人腾讯云服务器的是按照流量收费的，最近网站流量跑的比较快，所以打算接入cdn，把图片缓存下来，减少流量直接打到服务器上面。

## 步骤

### 注册又怕云账号

在[https://www.upyun.com/](https://www.upyun.com/)网站上面注册又拍云账号。

### 上传SSL证书

如下图将ssl的证书以及私钥上传到网站上面
![97e3c7b42955072fe62d6f4eef0face7.png](https://img.zeekling.cn/images/2020/06/07/97e3c7b42955072fe62d6f4eef0face7.png)

注意：在腾讯云上申请的ssl证书是key+crt 类型的，通过在网站[https://www.myssl.cn/tools/merge-pem-cert.html](https://www.myssl.cn/tools/merge-pem-cert.html)上面生成pem文件，复制到上面的框里面即可。

### cdn 加速

创建cdn服务，关联需要加速的网站，如下图所示。
![b7e05e71e16c528244f6a81336dd3899.png](https://img.zeekling.cn/images/2020/06/07/b7e05e71e16c528244f6a81336dd3899.png)

并且配置cname映射到新建cdn域名。

编辑cdn信息，在https一栏关联ssl证书，如下图所示。

在缓存一栏，增加缓存规则，主要缓存一些静态的资源。

如上图所示基本的cdn加速就已经构建起来了。还有一些其他功能可以自己摸索下。

我接入了博客和图床两个服务，博客缓存量没多少，但是图床缓存量比较多。

