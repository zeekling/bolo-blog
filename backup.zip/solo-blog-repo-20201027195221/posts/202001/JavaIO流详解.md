title: Java I/O流详解
date: '2020-01-13 23:03:15'
updated: '2020-01-13 23:03:15'
tags: [Java]
permalink: /articles/2020/01/13/1578927795391.html
---
![pic](https://img.zeekling.cn/images/2020/01/13/225317-1577976797c60f.jpg)

## 流的分类

- 按数据流的方向不同：输入流，输出流。
- 按处理数据单位不同：字节流，字符流。- 字节流：数据流中最小的数据单元是字节。
  - 字符流：数据流中最小的数据单元是字符， Java 中的字符是 Unicode 编码，一个字符占用两个字节。
- 按功能不同：节点流，处理流。- 程序用于直接操作目标设备所对应的类叫节点流。
  - 程序通过一个间接流类去调用节点流类，以达到更加灵活方便地读写各种类型的数据，这个间接流类就是处理流。

## 节点流

### 节点流的类型

- File 文件流。对文件进行读、写操作 ：FileReader、FileWriter、FileInputStream、FileOutputStream.
- Memory:* 从/向内存数组读写数据： CharArrayReader 与 CharArrayWriter、ByteArrayInputStream 与 ByteArrayOutputStream。
  * 从/向内存字符串读写数据 StringReader、StringWriter、StringBufferInputStream。
- Pipe 管道流：实现管道的输入和输出（进程间通信）: PipedReader 与 PipedWriter、PipedInputStream 与 PipedOutputStream。

### 节点流执行的图示

![2020-01-15_22-48.png](https://img.zeekling.cn/images/2020/01/15/2020-01-15_22-48.png)



未完待续
