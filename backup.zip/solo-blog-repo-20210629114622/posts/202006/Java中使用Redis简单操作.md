title: Java 中使用Redis 简单操作
date: '2020-06-22 00:40:37'
updated: '2020-08-20 23:34:11'
tags: [redis, Java, 转载]
permalink: /articles/2020/06/22/1592757637089.html
---
![223037-1567002637ad8a.jpg](https://img.zeekling.cn/images/2019/12/08/223037-1567002637ad8a.jpg)

## 简介

Redis 是完全开源免费的，遵守BSD协议，是一个高性能的key-value数据库。

Redis 与其他 key - value 缓存产品有以下三个特点：

* Redis支持数据的持久化，可以将内存中的数据保存在磁盘中，重启的时候可以再次加载进行使用。
* Redis不仅仅支持简单的key-value类型的数据，同时还提供list，set，zset，hash等数据结构的存储。
* Redis支持数据的备份，即master-slave模式的数据备份。

## 创建项目

创建gradle项目。在 `build.gradle`中添加：

```gradle
compile group: 'redis.clients', name: 'jedis', version: '3.3.0'

    testCompile group: 'junit', name: 'junit', version: '4.12'
```

## 创建Jedis连接池

```java
package com.zeekling.redis;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * @author zeekling [lingzhaohui@zeekling.cn]
 * @version 1.0
 * @apiNote redis 连接池
 * @since 2020-06-21
 */
public class RedisPool {

    //Redis服务器IP
    private static final String ADDR = "127.0.0.1";
    //Redis的端口号
    private static final Integer PORT = 6379;
    //访问密码
    private static final String AUTH = null;

    //可用连接实例的最大数目，默认为8；
    //如果赋值为-1，则表示不限制，如果pool已经分配了maxActive个jedis实例，则此时pool的状态为exhausted(耗尽)
    private static final Integer MAX_TOTAL = 1024;
    //控制一个pool最多有多少个状态为idle(空闲)的jedis实例，默认值是8
    private static final Integer MAX_IDLE = 200;
    //等待可用连接的最大时间，单位是毫秒，默认值为-1，表示永不超时。
    //如果超过等待时间，则直接抛出JedisConnectionException
    private static final Integer MAX_WAIT_MILLIS = 10000;
    private static final Integer TIMEOUT = 10000;
    //在borrow(用)一个jedis实例时，是否提前进行validate(验证)操作；
    //如果为true，则得到的jedis实例均是可用的
    private static final Boolean TEST_ON_BORROW = true;
    private  static JedisPool jedisPool = null;

    static {
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMaxTotal(MAX_TOTAL);
        config.setMaxIdle(MAX_IDLE);
        config.setMaxWaitMillis(MAX_WAIT_MILLIS);
        config.setTestOnBorrow(TEST_ON_BORROW);
        jedisPool = new JedisPool(config,ADDR,PORT,TIMEOUT,AUTH);
    }

    /**
     * 获取Jedis实例
     * @return jedis实例
     */
    public synchronized static Jedis getJedis(){
        try {
            if(jedisPool != null){
                return jedisPool.getResource();
            }else{
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}

```

## 创建测试类

```
package com.zeekling.redis;

import org.junit.Before;
import org.junit.Test;
import redis.clients.jedis.Jedis;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * @author zeekling [lingzhaohui@zeekling.cn]
 * @version 1.0
 * @apiNote
 * @since 2020-06-22
 */
public class RedisPoolTest {

    private Jedis jedis;

    @Before
    public void setJedis() {
        jedis = RedisPool.getJedis();
        if (jedis != null){
            jedis.flushAll();
        }
        System.out.println("连接服务成功");
    }


    /**
     * Redis操作字符串
     */
    @Test
    public void testString() {
        System.out.println("--------------begin test string--------------------");
        //添加数据
        jedis.set("name", "zeekling"); //key为name放入value值为chx
        System.out.println("拼接前:" + jedis.get("name"));//读取key为name的值

        //向key为name的值后面加上数据 ---拼接
        jedis.append("name", " is my name;");
        System.out.println("拼接后:" + jedis.get("name"));

        //删除某个键值对
        jedis.del("name");
        System.out.println("删除后:" + jedis.get("name"));

        //s设置多个键值对
        jedis.mset("name", "zeekling", "age", "20", "email", "zeekling@zeekling.cn");
        jedis.incr("age");//用于将键的整数值递增1。如果键不存在，则在执行操作之前将其设置为0。 如果键包含错误类型的值或包含无法表示为整数的字符串，则会返回错误。此操作限于64位有符号整数。
        System.out.println(jedis.get("name") + " " + jedis.get("age") + " " + jedis.get("email"));
        System.out.println("--------------end test string--------------------");
    }

    @Test
    public void testMap() {
        System.out.println("--------------begin test map--------------------");
        //添加数据
        Map<String, String> map = new HashMap<String, String>();
        map.put("name", "zeekling");
        map.put("age", "100");
        map.put("email", "zeekling@zeekling.cn");
        jedis.hset("user", map);
        //取出user中的name，结果是一个泛型的List
        //第一个参数是存入redis中map对象的key，后面跟的是放入map中的对象的key，后面的key是可变参数
        List<String> list = jedis.hmget("user", "name", "age", "email");
        System.out.println(list);

        //删除map中的某个键值
        jedis.hdel("user", "age");
        System.out.println("age:" + jedis.hmget("user", "age")); //因为删除了，所以返回的是null
        System.out.println("user的键中存放的值的个数:" + jedis.hlen("user")); //返回key为user的键中存放的值的个数2
        System.out.println("是否存在key为user的记录:" + jedis.exists("user"));//是否存在key为user的记录 返回true
        System.out.println("user对象中的所有key:" + jedis.hkeys("user"));//返回user对象中的所有key
        System.out.println("user对象中的所有value:" + jedis.hvals("user"));//返回map对象中的所有value

        //拿到key，再通过迭代器得到值
        for (String key : jedis.hkeys("user")) {
            System.out.println(key + ":" + jedis.hmget("user", key));
        }
        jedis.del("user");
        System.out.println("删除后是否存在key为user的记录:" + jedis.exists("user"));//是否存在key为user的记录
        System.out.println("--------------end test map--------------------");

    }

    @Test
    public void testList(){
        System.out.println("--------------begin test list--------------------");
        //移除javaFramwork所所有内容
        jedis.del("javaFramwork");
        //存放数据
        jedis.lpush("javaFramework","spring");
        jedis.lpush("javaFramework","springMVC");
        jedis.lpush("javaFramework","mybatis");
        //取出所有数据,jedis.lrange是按范围取出
        //第一个是key，第二个是起始位置，第三个是结束位置
        System.out.println("长度:"+jedis.llen("javaFramework"));
        //jedis.llen获取长度，-1表示取得所有
        System.out.println("javaFramework:"+jedis.lrange("javaFramework",0,-1));

        jedis.del("javaFramework");
        System.out.println("删除后长度:"+jedis.llen("javaFramework"));
        System.out.println(jedis.lrange("javaFramework",0,-1));
        System.out.println("--------------end test list--------------------");
    }

    @Test
    public void testSet(){
        System.out.println("--------------begin test set--------------------");
        //添加
        jedis.sadd("user","zeekling");
        jedis.sadd("user","hu");
        jedis.sadd("user","chen");
        jedis.sadd("user","xiyu");
        jedis.sadd("user","chx");
        jedis.sadd("user","are");
        //移除user集合中的元素are
        jedis.srem("user","are");
        System.out.println("user中的value:"+jedis.smembers("user"));//获取所有加入user的value
        System.out.println("chx是否是user中的元素:"+jedis.sismember("user","chx"));//判断chx是否是user集合中的元素
        System.out.println("集合中的一个随机元素:"+jedis.srandmember("user"));//返回集合中的一个随机元素
        System.out.println("user中元素的个数:"+jedis.scard("user"));
        System.out.println("--------------end test set--------------------");
    }

    /**
     * 排序
     */
    @Test
    public void test(){
        System.out.println("--------------begin test sort--------------------");
        jedis.del("number");//先删除数据，再进行测试
        jedis.rpush("number","4");//将一个或多个值插入到列表的尾部(最右边)
        jedis.rpush("number","5");
        jedis.rpush("number","3");

        jedis.lpush("number","9");//将一个或多个值插入到列表头部
        jedis.lpush("number","1");
        jedis.lpush("number","2");
        System.out.println(jedis.lrange("number",0,jedis.llen("number")));
        System.out.println("排序:"+jedis.sort("number"));
        System.out.println(jedis.lrange("number",0,-1));//不改变原来的排序
        jedis.del("number");//测试完删除数据
        System.out.println("--------------end test sort--------------------");
    }

}

```

## 备注

项目地址：[redis学习](https://git.zeekling.cn/zeekling/redis-test)
