title: 【Redis源码】setnx、setex、psetex命令
date: '2020-11-08 15:45:20'
updated: '2021-03-21 13:41:23'
tags: [源码, 命令, 转载, redis]
permalink: /articles/2020/11/08/1604821520818.html
---
![63ee990e471f8c245f9af368491949a9.jpg](https://img.zeekling.cn/images/2020/08/24/63ee990e471f8c245f9af368491949a9.jpg)

## 简介

在读本文之前，建议阅读文章：[Redis Set命令详解](/articles/2020/11/08/1604816679827.html).

在了解了set的原理之后，setnx、setex、psetex命令的原理我们也应该大致了解了，这3个命令也是先调用了tryObjectEncoding将值优化，再调用setGenericCommand将key-value设置到数据库，只不过这3个命令不需要解析额外参数。

## setnx命令

格式：

```bash
setnx key value
```

- 说明： 将key-value设置到数据库，当且仅当key不存在时。
- 源码分析： 在调用setGenericCommand时，将flags赋值为OBJ_SET_NX，表示只有key不存在时才可以执行函数。

## setex命令

格式：

```bash
setex key seconds value
```

- 说明： 将key-value设置到数据库，并且指定key的超时秒数。
- 源码分析： 在调用setGenericCommand时，将flags赋值为OBJ_SET_NO_FLAGS，expire赋值为UNIT_SECONDS，表示不需要考虑数据库中是否存在key，且时间单位为秒。

## psetex命令

格式：

```bash
psetex key milliseconds value
```

- 说明： 将key-value设置到数据库，并且指定key的超时毫秒数。
- 源码分析： 在调用setGenericCommand时，将flags赋值为OBJ_SET_NO_FLAGS，expire赋值为`UNIT_MILLISECONDS`，表示不需要考虑数据库中是否存在key，且时间单位为毫秒。
