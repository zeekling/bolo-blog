title: frp 内网穿透
date: '2019-08-11 13:29:17'
updated: '2020-10-26 23:59:30'
tags: [frp]
permalink: /articles/2019/08/11/1565501357107.html
---
![88742c21d195b1499e47d468877d43c8.jpg](https://img.zeekling.cn/images/2020/08/23/88742c21d195b1499e47d468877d43c8.jpg)

## 目的

本人使用了树莓派作为了家里一直吃灰的服务器，想让树莓派上面的东西外网可以访问(博客也是部署在树莓派上面的),所以就有了 frp 内网穿透这一说法。

## frps

首先需要一台远程服务器，我选择的是阿里云的服务器，最开始选择的国外的 vultr,后来试了下 hostwind,要么是网速比较慢，要么是丢包比较严重，所以放弃了，选择了阿里云香港区的服务器，也是可以翻墙，虽然总体算下来应该比国外的贵一点。但是网速快。而且我选择的是最便宜的，所以就可以忽略了。哈哈哈

1. 下载 frp 软件，地址[https://github.com/fatedier/frp/releases](https://github.com/fatedier/frp/releases) 并且解压到`/usr/local/frps` 下面
2. 修改配置，我的配置主要如下：

```json
[common]
bind_port = 7000
vhost_http_port = 8080
vhost_https_port = 4443
bind_udp_port = 7001
admin_port = 7400
admin_user = admin
admin_pwd = admin
max_pool_count = 5
dashboard_port = 7500
dashboard_pwd = admin
max_pool_count = 100
token = 123456
```

1. 到`/usr/local/frps` 下面执行`./frps -c ./frps.ini &` 就可以了
2. 增加定时任务：`*/1 * * * * cd /usr/local/frps && ./frps -c frps.ini  &`

## frpc

1. 修改配置

```json
[common]
server_addr = aliyun ip
server_port = 7000
token = 123456
pool_count = 100
login_fail_exit = false
use_compression = true
use_encryption = true

[ssh]
type = tcp
local_ip = 127.0.0.1
local_port = 22
remote_port = 6000
custom_domains = ssh.zeekling.cn
use_compression = true
use_encryption = true

[root]
type = http
local_port = 80
custom_domains = zeekling.cn
use_compression = true
use_encryption = true

[www]
type = http
local_port = 80
custom_domains = www.zeekling.cn
use_compression = true
use_encryption = true

[blog]
type = http
local_port = 8080
custom_domains = blog.zeekling.cn
use_compression = true
use_encryption = true

[pan]
type = http
local_port = 81
custom_domains = www.zeek-pan.cn
use_compression = true
use_encryption = true
```

1. 连接 frps

```bash
./frpc -c ./frpc.ini > /tmp/frpc.log 2>&1 &
```

1. 监控脚本

```bash
frp=`ps -ef | grep frpc | wc -l`
if [ "${frp}" -eq "1" ];then
        cd frp_0.26.0_linux_arm && ./frpc -c ./frpc.ini > /tmp/frpc.log 2>&1 &
fi
```

## frps 和 nginx 都是用 80 端口

nginx 加入如下配置即可

```nginx
server {
        listen 80 default_server;
        listen [::]:80 default_server;

        root /var/www/html;

        index index.html index.htm index.nginx-debian.html;

        server_name _;

        location / {
                proxy_pass http://127.0.0.1:8080; # 本地服务器地址
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;
                proxy_set_header Upgrade $http_upgrade;
                proxy_set_header Connection "upgrade";
        }

        location ~ .(jpg|png|gif|css|js)$ { # 缓存
                proxy_pass http://127.0.0.1:8080; # 本地服务器地址
                proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
                proxy_set_header Host $http_host;
                proxy_set_header Upgrade $http_upgrade;
                proxy_set_header Connection "upgrade";
                proxy_cache cache_one;
                proxy_cache_valid 200 302 1h;
                proxy_cache_valid 301 1d;
                proxy_cache_valid any 1m;
                expires 30d;
                proxy_redirect off;
                add_header wall "hey!guys!give me a star.";
        }
}
```
