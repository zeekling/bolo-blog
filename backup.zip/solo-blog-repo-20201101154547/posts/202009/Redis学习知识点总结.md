title: Redis 学习知识点总结
date: '2020-09-01 00:46:21'
updated: '2020-10-20 20:56:05'
tags: [redis, 原创, 知识总结]
permalink: /articles/2020/09/01/1598892381872.html
---
![a1ad3bf612a8d8bd1b1ecb30eb9c26af.jpg](https://img.zeekling.cn/images/2020/08/23/a1ad3bf612a8d8bd1b1ecb30eb9c26af.jpg)

## 简介

本文的主要目的就是对之前看过的Redis相关的文章做一个简单的提纲，方便以后汇总复习。

## 基础知识

- [使用java API对redis进行简单操作](https://www.zeekling.cn/articles/2020/06/22/1592757637089.html)
- [redis数据清理](https://www.zeekling.cn/articles/2020/07/04/1593860561539.html)
- [理解Redis内存](https://www.zeekling.cn/articles/2020/07/04/1593860561539.html)
- [redis cluster详解](https://www.zeekling.cn/articles/2020/07/21/1595342026052.html)
- [redis哨兵模式详解](https://www.zeekling.cn/articles/2020/07/21/1595343778998.html)
- [redis慢查询分析](https://www.zeekling.cn/articles/2020/07/23/1595493094855.html)
- [redis数据结构skiplist详解](https://www.zeekling.cn/articles/2020/08/30/1598796820320.html)

## 源码阅读

- [Redis源码注释](https://git.zeekling.cn/zeekling/redis)
- [vscode 查看Redis源码](/articles/2020/10/20/1603198382711.html)
- [Redis启动过程分析](/articles/2020/09/25/1601041404734.html)
- [Redis事件监听](/articles/2020/10/06/1601975298948.html)
- [Redis命令执行过程](/articles/2020/10/09/1602258239840.html)
