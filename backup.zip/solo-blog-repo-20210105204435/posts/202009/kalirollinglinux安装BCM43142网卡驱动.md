title: kali rolling linux 安装BCM43142网卡驱动
date: '2020-09-26 11:40:35'
updated: '2020-09-26 11:51:23'
tags: [原创, linux, kali]
permalink: /articles/2020/09/26/1601091635148.html
---
![0ed8ba6ee2cb0263916e6d687bcc8647.jpg](https://img.zeekling.cn/images/2020/08/23/0ed8ba6ee2cb0263916e6d687bcc8647.jpg)

> 手动迁移csdn 2016年博客。

## 前言

玩linux已经有半年多的时间了，在这半年时间里，我的linux系统重装了已经不下于十次了吧。最近心血来潮，玩了一把kali linux (大学霸)，除了无线网卡驱动没有之外，其他的都很满意，比之前用的ubuntu系列的好多了。我知道有好多人都在用ubuntu系统，主要是因为这个系统用的人多，社区力量比较大，你能遇到的问题别人都已经遇到过了，在网上都可以找到很多关于ubuntu这个系统出问题之后的解决方案。ubuntu的确是入门的好东西。但是他也有好多缺点：不怎么稳定，在ubuntu用过一段时间之后，你会发现电脑开机之后会弹出很多错误信息，我特别讨厌这个，就把这个弹框禁止了，后来开机就没有这个可恶的东西了。但是如果不禁止的话这个就有点不友好了。ubuntu的源太旧了，有好多软件用apt 安装后会发现版本太旧了，根本没办法用，然后的自己从官网上下载，然后编译安装。对于一个想学好linux 的人来说，这些不算什么，但是源太旧的话就失去了源存在的意义了，不是吗。最后我觉着ubuntu的界面实在是不好看，尽管网上有人说ubuntu的界面不错，但是我觉得真的不好看，当然桌面可以自己装，这个不算什么。 <br>

## 第一步：安装内核头文件

我用的是滚动版的kali linux，系统刚安装好之后内核版本不是较新的4.6.0，而是4.3.0所以要做的就是就是跟新一下系统：

- 在

```
vi /etc/apt/sources.list
```

中添加

```
deb http://http.kali.org/kali kali-rolling main non-free contrib  
```

或者

```
deb http://mirrors.ustc.edu.cn/kali kali-rolling main non-free contrib
```

- 执行

```
sudo apt update && sudo apt upgrade
```

- 跟新 完了之后执行

```
sudo apt install linux-headers-`uname -r`
```

## 安装BCM43142网卡驱动

安装网卡驱动有两种方法：一种是编译源码然后安装，另一种是安装利用图形化包管理软件或者命令行安装二进制文件。第二种方法只讲用命令行安装。

### 编译源码，安装网卡驱动

源码地址：https://github.com/lzh-fork/broadcom-wl 或者 https://github.com/akrasic/broadcom-wl  <br>
按照上面的提示一步一步可以完成网卡驱动的安装，当然在安装的过程中可能会出现许多依赖问题。

### 命令行安装

在终端里面输入

```
sudo apt install broadcom-sta-dkms
```

即可完成网卡驱动安装。重启电脑就可以看到电脑可以连接无线网了，好开心。

![这里写图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL2ltZy5ibG9nLmNzZG4ubmV0LzIwMTYwODE5MTQ1MTU0MDcz)
我的安装好了，所以输入命令时是这样的
![这里写图片描述](https://imgconvert.csdnimg.cn/aHR0cDovL2ltZy5ibG9nLmNzZG4ubmV0LzIwMTYwOTAzMDk1MDEyOTA3)
最后祝君好运！
