title: 【Redis源码】strlen命令
date: '2020-11-11 20:47:31'
updated: '2021-03-21 13:39:47'
tags: [转载, 源码, redis]
permalink: /articles/2020/11/11/1605098851638.html
---
![1a499869e2f8ac76267e5c29fa68cda4.jpg](https://img.zeekling.cn/images/2020/08/23/1a499869e2f8ac76267e5c29fa68cda4.jpg)

## 简介

strlen命令从数据库中获取到value，返回value字符串的长度。

**格式：**

```bash
strlen key
```

## strlen 命令

Redis获取到值robj的ptr之后，如果值类型是string类型，通过sdslen函数便可以获取到value的长度。如果值类型不是string类型，通过递归可以求出整型值的字符串长度：

```cpp
uint32_t digits10(uint64_t v) {
    if (v < 10) return 1;
    if (v < 100) return 2;
    if (v < 1000) return 3;
    if (v < 1000000000000UL) {
        if (v < 100000000UL) {
            if (v < 1000000) {
                if (v < 10000) return 4;
                return 5 + (v >= 100000);
            }
            return 7 + (v >= 10000000UL);
        }
        if (v < 10000000000UL) {
            return 9 + (v >= 1000000000UL);
        }
        return 11 + (v >= 100000000000UL);
    }
    return 12 + digits10(v / 1000000000000UL);
}
```
