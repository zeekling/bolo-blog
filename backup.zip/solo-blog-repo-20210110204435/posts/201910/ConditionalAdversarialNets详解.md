title: Conditional Adversarial Nets 详解
date: '2019-10-19 22:35:34'
updated: '2020-05-24 12:25:52'
tags: [机器学习, 论文]
permalink: /articles/2019/10/19/1571495734883.html
---
![](https://pan.zeekling.cn/V5I_201809306993731639775391758.jpg) 

## 简介
本文提出在利用 GAN（对抗网络）的方法时，在生成模型G和判别模型D中都加入条件信息来引导模型的训练，并将这种方法应用于跨模态问题，例如图像自动标注等。

## Generative Adversarial Nets

GAN，生成对抗式网络是是Ian Goodfellow经典的大作，引起了很大的轰动，后面的各种GAN也层出不穷。追根溯源，为了了解GAN，需要从这篇开山之作说起。那GAN到底是什么？简单来说，GAN由两个模型组成，一个是生成模型G，一个是判别模型D，G负责从给定训练数据中学习数据的概率分布而D负责判别G生成出来的数据是不是符合真实数据的样本概率分布。两个网络是非合作关系，对于D来说，是要最大化能够判别出G生成的数据是假的的概率，而对于G来说，是要最小化被D判别出来的概率，在这个不断博弈的过程中，两个模型的能力都在变强，最后得到一个均衡。

![图片1.png](https://pan.zeekling.cn/TkP_0e9011943719264734583661098.png)

模型G和D同时训练：固定判别模型D，调整G的参数使得 log(1 − D(G(z))的期望最小化；固定生成模型G，调整D的参数使得$logD(X) + log(1 − D(G(z)))$的期望最大化。这个优化过程可以归结为一个“二元极小极大博弈（minimax two-player game）”问题:

![Screenshotat20191019223453.png](https://pan.zeekling.cn/GCg_aab2a09b1843042896875218321.png)

         D(x)为分类器，  G(x)为生成器
         D(x)的输入为真实数据或生成数据， G(x)的输入为随机高斯噪声z
         对于D(x)来说应该最大化损失函数
         对于G(x)来说应该最小化损失函数
         相当于两个模块的博弈，而最后D(x)的预测概率为1/2则是达到了纳什均衡，也是最优解

算法训练过程

![训练过程](https://img-blog.csdn.net/20170618203729854)

## Conditional Adversarial Nets
由于GAN这种不需要预先建模的方法太过自由，如果对于较大图片，较多像素的情形，这种基于GAN的方法就太不可控了。

为了解决上述问题，自然就想到给GAN模型加入一些条件约束，也就有了本文的工作Conditional Generative Adversarial Nets(CGAN)。在生成模型G和判别模型D中同时加入条件约束y来引导数据的生成过程。条件可以是任何补充的信息，如类标签，其它模态的数据等，这样使得GAN能够更好地被应用于跨模态问题，例如图像自动标注。

![约束条件](https://pic2.zhimg.com/80/v2-239d9f40edd8b90f8ea4eced4471d649_hd.png)

把噪声z和条件y作为输入同时送进生成器，生成跨域向量，再通过非线性函数映射到数据空间。  

把数据x和条件y作为输入同时送进判别器，生成跨域向量，并进一步判断x是真实训练数据的概率。
算法简单流程:
![Screenshotat20191020154354.png](https://pan.zeekling.cn/4IV_0d8753dd1951903706692293792.png)


条件对抗网络损失函数:
![损失函数](https://www.zhihu.com/equation?tex=%5Cmin_%7BG%7D+%5Cmax_%7BD%7DV%28D%2CG%29%3DE_%7Bx%5Csim+p_%7Bdata%7D%7B%28x%29%7D%7D%5BlogD%28x%7Cy%29%5D%2BE_%7Bz%5Csim+p_%7Bz%7D%7B%28z%29%7D%7D%5Blog%281-D%28G%28z%7Cy%29%29%29%5D)



## 参考文档
> [Generative Adversarial Nets](https://arxiv.org/pdf/1406.2661v1.pdf)
> [Conditional Generative Adversarial Nets](https://arxiv.org/pdf/1411.1784.pdf)
