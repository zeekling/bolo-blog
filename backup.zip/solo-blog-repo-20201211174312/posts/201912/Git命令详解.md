title: Git 命令详解
date: '2019-12-01 15:13:46'
updated: '2020-12-10 22:27:14'
tags: [git]
permalink: /articles/2019/12/01/1575184426144.html
---
## 简介

Git(读音为/g ɪt/。)是一个开源的分布式版本控制系统，可以有效、高速地处理从很小到非常大的项目版本管理。 [1]  Git 是 [Linus Torvalds](https://baike.baidu.com/item/Linus+Torvalds/9336769) 为了帮助管理 Linux 内核开发而开发的一个开放源码的版本控制软件。

本文主要记录自己使用过程中用过的 Git 相关命令。

## 常用命令

- 克隆远程仓库到本地`git clone [git地址]`,比如：

```shell
git clone git@git.zeekling.cn:java/designPattern.git
```

- 查看 Git 仓库信息`git remote show [remote-name]`, 比如：

```shell
git remote show origin
```

- Git 删除远程仓库

```sh
git branch -r -d origin/branch-name
git push origin :branch-name
```

- git 同时提交到多个远程仓库,添加仓库源即可并且push上去即可。

```sh
git remote add sundyn ssh://git@git.zeekling.cn:222/deep-learn/chatbot-list.git
git push sundyn master
```

- 跟新远程git分支信息

```sh
git remote update origin --prune
```

* 跟新仓库子模块

```bash
git submodule update --init --recursive
```
