title: Java 面试知识整理以及汇总
date: '2020-01-02 22:04:16'
updated: '2020-01-02 22:04:16'
tags: [Java]
permalink: /articles/2020/01/02/1577973856241.html
---
## 简介

Java 基础知识比较多，每次使用的时候都是网上搜搜，有时候并不全面，所以打算自己整理下，方便以后查看。

## Java 基础知识

- [字符型常量和字符串常量的区别](https://www.jianshu.com/p/4cad274e71d0)
- [Java 面向对象编程三大特性: 封装 继承 多态](https://blog.csdn.net/qq_22118507/article/details/51422591)-
- [重载和重写的区别](https://www.jianshu.com/p/2bb61c01fe54)
- [String StringBuffer 和 StringBuilder 的区别是什么? String 为什么是不可变的?](https://blog.csdn.net/dorapan1987/article/details/44347933)
- [自动装箱与拆箱](https://droidyue.com/blog/2015/04/07/autoboxing-and-autounboxing-in-java/)
- [接口和抽象类的区别是什么？](https://www.jianshu.com/p/038f0b356e9a)
- [Java 中 equals 和 == 的区别](https://www.cnblogs.com/qianguyihao/p/3929585.html)
- [hashCode 与 equals](https://www.jianshu.com/p/6823a9da5a52)
- 数据类型
  - [基本数据类型:数值类型,整型,浮点型,boolean](https://www.cnblogs.com/doit8791/archive/2012/05/25/2517448.html)
  - [引用数据类型:强引用,软引用,弱引用,虚引用](https://www.jianshu.com/p/d7eed43a00e4)

* [Java 集合](https://juejin.im/post/5ad82dbef265da503825b240)
  * [List](https://blog.csdn.net/tianyijavaoracle/article/details/41645393)
    * ArrayList
    * LinkedList
    * [CopyOnWriteArrayList](https://www.cnblogs.com/myseries/p/10877420.html)
    * Vector
  * Set
    * Hashset
    * TreeSet
  * Map
    * [HashMap](https://blog.csdn.net/vking_wang/article/details/14166593)
    * HashTable
    * [ConcurrentHashMap](https://blog.csdn.net/sunmenggmail/article/details/8117805)

- [io 流](https://blog.csdn.net/qq_33642117/article/details/52074796)
  - [NIO](https://juejin.im/post/5d843c58518825731a65836d)
  - [AIO](https://juejin.im/post/5d843c58518825731a65836d)
  - [NIO](https://juejin.im/post/5d843c58518825731a65836d)

* [并发编程]()
  * [多线程的实现方式](https://blog.csdn.net/king_kgh/article/details/78213576)
  * [synchronized 底层如何实现？什么是锁的升级、降级](https://www.twblogs.net/a/5c3603f4bd9eee35b21d34c4/zh-cn)

- [Java 8 新特性](https://www.ibm.com/developerworks/cn/java/j-lo-jdk8newfeature/index.html)

* [Java 9 新特性](https://www.runoob.com/java/java9-new-features.html)

## JVM 相关知识

### JVM 详解

- [内存详解](https://www.zeekling.cn/articles/2020/01/18/1579326364846.html)
- [对象详解](https://www.zeekling.cn/articles/2020/01/18/1579344932298.html)
- 垃圾回收
- class 文件详解
- [类加载机制]([https://www.zeekling.cn/articles/2020/01/12/1578818636373.html](https://www.zeekling.cn/articles/2020/01/12/1578818636373.html))

### 问题排查

## Java 相关框架

- Spring
- Spring boot

## Java 工具

- maven
- gradle

## 关系型数据库

- MySQL
  - [MySQL 数据库优化两三事 ](https://sq.163yun.com/blog/article/183654375478206464)
  - [MySQL 数据库优化的思路](http://www.jishuchi.com/read/mysql-interview/2810)
  - [MySQL SQL 优化](http://www.jishuchi.com/read/mysql-interview/2818)
  - [SQL 连接可以分为内连接、外连接、交叉连接。](https://www.cnblogs.com/zxlovenet/p/4005256.html)
  - [【Java 面试题】MySQL 高频面试 60 题含答案](https://zhuanlan.zhihu.com/p/61273508)
- Oracle

## 非关系型数据库

- mongo

## 缓存

- Redis

## 备注

暂时只列了大致的提纲，后续会慢慢完善。

https://zhuanlan.zhihu.com/p/91548097
