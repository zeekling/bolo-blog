title: bolo博客图片显示优化
date: '2020-08-21 01:42:47'
updated: '2020-08-23 17:20:26'
tags: [博客, bolo, 原创]
permalink: /articles/2020/08/21/1597945367713.html
---
![mmexport1582213541433.jpg](https://img.zeekling.cn/images/2020/02/23/mmexport1582213541433.jpg)

## 原因

想改这个图片显示的原因是博客里面的图片点击之后就会直接跳转，优点烦躁于是就改了皮肤bolo-fantastic的图片显示样式。

## 使用

引入layer 相关lib包：

```html
<script src="https://www.zeekling.cn/skins/bolo-fantastic/js/layer.js"> </script>
```

修改图片显示样式

```
<script type="text/javascript" >
$(document).ready(function(){
	$(".gallery-item").each(function(){
		var href = $(this).attr("href");
		var img = $(this).find("img");
		var w = img.width;
		var h = img.height;
	    $(this).attr("href","javascript:void(0)");
	});
	$(".gallery-item").on("click",function(){
        var img = $(this).find("img");
		var w = img.width;
		var h = img.height;
		var url = $(img).attr("src");
		var alt = $(img).attr("alt");
		showImage(w, h, url, alt);
	});
});

function showImage(w, h,url, alt){
	layer.photos({
		photos:{
			"title":"${blogTitle!}图片显示",
			"id":"",
			"data":[{
				"alt":alt,
				"src":url,
				"thumb":url
			}]
		},anim: 0
	});
}
</script>
```

最后结果如下：

![202008210138.png](https://pan.zeekling.cn/VsDUn10Q53)
