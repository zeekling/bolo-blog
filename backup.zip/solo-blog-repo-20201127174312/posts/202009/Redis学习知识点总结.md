title: Redis 学习知识点总结
date: '2020-09-01 00:46:21'
updated: '2020-11-24 00:43:39'
tags: [redis, 原创, 知识总结]
permalink: /articles/2020/09/01/1598892381872.html
---
![a1ad3bf612a8d8bd1b1ecb30eb9c26af.jpg](https://img.zeekling.cn/images/2020/08/23/a1ad3bf612a8d8bd1b1ecb30eb9c26af.jpg)

## 简介

本文的主要目的就是对之前看过的Redis相关的文章做一个简单的提纲，方便以后汇总复习。

## 基础知识

记录Redis基本知识，用于以后复习使用。

| 文章标题 | 类型 |
| - | - |
| [使用java API对redis进行简单操作](https://www.zeekling.cn/articles/2020/06/22/1592757637089.html) | API操作 |
| [Redis数据清理](https://www.zeekling.cn/articles/2020/07/04/1593860561539.html) | 基本原理 |
| [理解Redis内存](https://www.zeekling.cn/articles/2020/07/04/1593860561539.html) | 内存相关 |
| [Redis cluster详解](https://www.zeekling.cn/articles/2020/07/21/1595342026052.html) | 集群模式 |
| [Redis哨兵模式详解](https://www.zeekling.cn/articles/2020/07/21/1595343778998.html) | 集群模式 |
| [Redis慢查询分析](https://www.zeekling.cn/articles/2020/07/23/1595493094855.html) | 慢查询 |
| [Redis 6新特性](/articles/2020/11/01/1604242049779.html) | Redis 6 特性 |
| [Redis 6.0新特性——ACLs](/articles/2020/11/22/1606048977051.html) | Redis 6 特性 |

## Redis常见故障处理方法

主要记录遇到的Redis常见的问题以及处理方式和产生的原因。

| 文章标题 | 类型 |
| - | - |
| [当Redis数据磁盘坏掉之后会发生什么](/articles/2020/11/09/1604937462651.html) | 磁盘故障 |

## Redis源码阅读

本人阅读Redis 6 源码，并且做出一些相关的笔记，用作备忘。

| 文章标题 | 类型 |
| - | - |
| [Redis源码注释](https://git.zeekling.cn/zeekling/redis) | 基础操作 |
| [vscode 查看Redis源码](/articles/2020/10/20/1603198382711.html) | 基础操作 |
| [Redis启动过程分析](/articles/2020/09/25/1601041404734.html) | 启动 |
| [Redis事件监听](/articles/2020/10/06/1601975298948.html) | 启动 |
| [Redis命令执行过程](/articles/2020/10/09/1602258239840.html) | 命令 |
| [Redis Set命令详解](/articles/2020/11/08/1604816679827.html) | 命令 |
| [setnx、setex、psetex命令详解](/articles/2020/11/08/1604821520818.html) | 命令 |
| [mset命令详解](/articles/2020/11/08/1604831354258.html) | 命令 |
| [append命令详解](/articles/2020/11/08/1604838367145.html) | 命令 |
| [setrange命令详解](/articles/2020/11/08/1604841590957.html) | 命令 |
| [strlen命令](/articles/2020/11/11/1605098851638.html) | 命令 |
| [Redis数据结构skiplist详解](https://www.zeekling.cn/articles/2020/08/30/1598796820320.html) | 内部结构 |
| [Redis 6 ACL源码详解](/articles/2020/11/22/1606060178482.html) | Redis 6 特性 |
