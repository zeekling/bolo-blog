title: Redis 6.0新特性——ACLs
date: '2020-11-22 20:42:57'
updated: '2020-11-22 21:11:46'
tags: [原创, 命令, redis, 新特性]
permalink: /articles/2020/11/22/1606048977051.html
---
![c1669cfbc2b2909dcdb0131c1ffdceb6.jpg](https://img.zeekling.cn/images/2020/08/24/c1669cfbc2b2909dcdb0131c1ffdceb6.jpg)

## 简介

Redis在6版本之前是没有权限的概念的，所以所有连接的客户端都可以对Redis里面的数据进行操作，也可以使用所有高危命令，这样就可能存在Redis直接down掉或者数据被全部清空的情况。

- 当执行`flushall` 或者`flashdb`的时候会清空掉数据库里面的所有数据。
- 当执行`DEBUG SEGFAULT`的时候Redis进程会直接down掉。如下图所示：![202011221955.png](https://pan.zeekling.cn/wQR_2020-11-22_19-55.png)

在Redis 5以及之前的版本为了避免这种情况的出现，可以使用 `rename-command`将高危命令禁用掉。

```properties
rename-command KEYS ""
rename-command FLUSHALL ""
rename-command FLUSHDB ""
rename-command CONFIG ""
rename-command EVAL ""
rename-command SHUTDOWN ""
```

以上方法虽然可以解决掉高危命令带来的问题，但是只是使用了简单粗暴的方式，没有做的比较细致。

## ACL 权限

Redis ACL是Access Control List（访问控制列表）的缩写，该功能允许根据可以执行的命令和可以访问的键来限制某些连接。它的工作方式是，在连接之后，要求客户端进行身份验证，以提供用户名和有效密码：如果身份验证阶段成功，则连接与给定用户关联，并且该用户具有限制。可以对Redis进行配置，以使新连接已过“默认”用户进行身份验证（这是默认配置），因此，配置默认用户具有的能力是，仅向连接提供特定功能子集的功能未明确认证。

为某个用户设置权限可以使用下面命令：

```bash
ACL SETUSER test >passwd on allkey +set
```

`setuser`...`on`表示启用此用户，off则是只定义一个不可用（unaccessable）的用户。

`>passwd`表示给当前用户设置密码，可以通过auth命令进行登录acl控制的用户。

```bash
auth test passwd
```

![202011222015.png](https://pan.zeekling.cn/H8D_2020-11-22_20-15.png)

`+set`当前用户拥有执行set命令的权限，与之相反的是 `-set`表示取消指定用户执行set命令的权限。

切换用户之后只对指定的命令拥有执行权限。

![image.png](https://pan.zeekling.cn/grX_image.png)

## acl 配置文件

一般情况下，我们使用命令行设置的acl权限只是保存在内存里面，当Redis进程重启之后我们设置的权限就不见了。那我们应该怎么办呢，对于这种情况，官方也想到了，提供了acl的配置文件。在Redis的配置文件(redis.conf)中可以配置acl文件的位置：

```properties
aclfile /etc/redis/users.acl
```

那么acl里面到底保存的是什么呢？其实acl里面保存的就是命令 `acl list`执行的结果。其中密码的经过加密了的也比较安全。

下图是acl配置文件的样例，是通过执行命令 `acl save`生成的。

![image.png](https://pan.zeekling.cn/fWh_image.png)

下图是命令 `acl list`执行的结果。

![image.png](https://pan.zeekling.cn/3wN_image.png)

## 注意

acl 权限不会自动写入到配置文件里面，在生成ACL配置文件的时候一定要注意执行夏明命令进行持久化(需要先配置 `aclfile`)

```bash
acl save
```
