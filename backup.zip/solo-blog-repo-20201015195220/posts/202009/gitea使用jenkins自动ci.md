title: 'gitea 使用jenkins 自动ci '
date: '2020-09-13 21:12:08'
updated: '2020-10-07 22:42:30'
tags: [原创, 博客]
permalink: /articles/2020/09/13/1600002728592.html
---
![20b528052c7eb1676c0f83915a7f144a.jpg](https://img.zeekling.cn/images/2020/08/23/20b528052c7eb1676c0f83915a7f144a.jpg)

## 简介

我目前使用的代码仓库是使用`gitea`搭建而成的，详细参见[https://git.zeekling.cn](https://git.zeekling.cn/), 最近在看[redis源码](https://git.zeekling.cn/zeekling/redis)于是就想着加个自动ci的东西。

## 安装jenkins

执行下面脚本安装jenkins

```bash
docker pull jenkins/jenkins
docker stop jenkins
docker rm jenkins
docker run -d -t \
        -p 8888:8080 \
        -p 50000:50000 \
        -v /dockerData/jenkins/:/var/jenkins \
        --name=jenkins \
        jenkins/jenkins
```

## 安装gitea插件

到网站[https://plugins.jenkins.io/gitea/](https://plugins.jenkins.io/gitea/)中下载gitea插件。如下图所示上传gitea插件：

![202009132056.png](https://pan.zeekling.cn/ixR_2020-09-13_20-56.png)

![202009132058.png](https://pan.zeekling.cn/5KH_2020-09-13_20-58.png)

## 配置gitea

在gitea应用下面新增Tokens

在Manager->Configure System 下面新增gitea token信息

![202009132104.png](https://pan.zeekling.cn/kAe_2020-09-13_21-04.png)

## 新建jenkins ci

在所需要ci的项目里面新增文件Jenkinsfile，写入编译脚本

```json
pipeline {
    agent any

    stages {
        stage('Build') {
            steps {
                sh 'bash build.sh'
            }
        }
    }
}
```

选择新增items，选择Gitea Organization，并且选择自己添加的gitea条目。

## 结果展示

结果如下：

![202009132110.png](https://pan.zeekling.cn/SRS_2020-09-13_21-10.png)

提交完之后可以选是编译通过：

![202009132111.png](https://pan.zeekling.cn/Wad_2020-09-13_21-11.png)

