title: bolo 博客接入又拍云图床
date: '2020-06-09 01:43:23'
updated: '2020-10-07 22:44:05'
tags: [原创, bolo, 博客]
permalink: /articles/2020/06/09/1591638203577.html
---
![994e3459dece19415270f68eba28cbab.jpg](https://img.zeekling.cn/images/2020/07/23/994e3459dece19415270f68eba28cbab.jpg)

## 简介

我之前博客里面的图片都是用了自己搭建的[相册](https://img.zeekling.cn/)里面的，但是毕竟不太方便。并且最近正在搞又拍云的cdn。就顺手把图床这个是也搞定了吧。

## 创建云存储

首先需要在点击云产品>基础产品>云存储，创建云存储，如下图所示，并且选择操作员。如果没有操作员或者只有自己当前登录的账号，就新建一个操作员并且赋予读、写的权限。
![202006090132.png](https://pan.zeekling.cn/7KJvdfKS8o)

操作员的密码是随机生成的，记得保存下来。

## 接入域名

参照上一篇博客[博客接入又拍云cdn](https://www.zeekling.cn/articles/2020/06/07/1591520906274.html) 上传ssl证书，并且关联到图床的域名上面，即可。
![202006090142.png](https://pan.zeekling.cn/RVwG3HrmDW)

## bolo博客接入图床

自己申请的填写下面信息。

![202006090138.png](https://pan.zeekling.cn/VeJtXtTBRo)

