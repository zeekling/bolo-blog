title: 关于Redis 6 ACL特性的思考
date: '2021-04-19 23:13:08'
updated: '2021-04-19 23:13:30'
tags: [redis, 原创, ACL]
permalink: /articles/2021/04/19/1618845188228.html
---
![mmexport1582213709641.jpg](https://img.zeekling.cn/images/2020/02/23/mmexport1582213709641.md.jpg)

## 简介

ACL的使用详见我的另一篇文章：[Redis 6.0新特性——ACLs](https://www.zeekling.cn/articles/2020/11/22/1606048977051.html)。源码详解参见：[【Redis源码】Redis 6 ACL源码详解](https://www.zeekling.cn/articles/2020/11/22/1606060178482.html)。

## 思考

在使用的过程中发现Redis ACL 只是针对单个Redis实例而言的，但是在生产环境我们一定用的是哨兵模式或者集群模式，那么就存在Redis集群中实例ACL权限信息的同步问题。
