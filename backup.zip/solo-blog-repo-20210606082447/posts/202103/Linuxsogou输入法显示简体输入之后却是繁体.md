title: Linux sogou输入法显示简体，输入之后却是繁体
date: '2021-03-25 20:33:56'
updated: '2021-03-31 20:42:11'
tags: [输入法, linux, kali]
permalink: /articles/2021/03/25/1616675636194.html
---
![6a50982d1e178cb8929f44f00a4340f2.jpg](https://img.zeekling.cn/images/2020/08/24/6a50982d1e178cb8929f44f00a4340f2.jpg)

## 背景

最新linux电脑搜狗输入法老是在输入的时候显示中文简体，但是输入到文件，或者浏览器里面就变成了繁体。很是让人头疼，网上搜了下也没人讲这种事。

## 原因

后来我发现fcitx上面设置的是繁体。点下下面这个位置就行了，切换之后如下图所示。

![切换fcitx简繁体](https://pan.zeekling.cn/1F3_image.png)

可见所有莫名其妙的问题背后的原因都很瓜皮。

