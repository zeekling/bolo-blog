title: Error Downloading MNIST解决方案
date: '2019-07-07 13:29:53'
updated: '2020-11-02 22:39:51'
tags: [机器学习, python]
permalink: /articles/2019/07/07/1562477393183.html
---
## 问题描述

在下载MNIST数据集的时候报错,报错信息如下:

```python
/usr/local/lib/python3.7/dist-packages/sklearn/utils/deprecation.py:77: DeprecationWarning: Function fetch_mldata is deprecated; fetch_mldata was deprecated in version 0.20 and will be removed in version 0.22
  warnings.warn(msg, category=DeprecationWarning)
/usr/local/lib/python3.7/dist-packages/sklearn/utils/deprecation.py:77: DeprecationWarning: Function mldata_filename is deprecated; mldata_filename was deprecated in version 0.20 and will be removed in version 0.22
  warnings.warn(msg, category=DeprecationWarning)
Traceback (most recent call last):
  File "classification_sklearn.py", line 2, in <module>
    mnist = fetch_mldata('MNIST original')
  File "/usr/local/lib/python3.7/dist-packages/sklearn/utils/deprecation.py", line 78, in wrapped
    return fun(*args, **kwargs)
  File "/usr/local/lib/python3.7/dist-packages/sklearn/datasets/mldata.py", line 133, in fetch_mldata
    mldata_url = urlopen(urlname)
  File "/usr/lib/python3.7/urllib/request.py", line 222, in urlopen
    return opener.open(url, data, timeout)
  File "/usr/lib/python3.7/urllib/request.py", line 525, in open
    response = self._open(req, data)
  File "/usr/lib/python3.7/urllib/request.py", line 543, in _open
    '_open', req)
  File "/usr/lib/python3.7/urllib/request.py", line 503, in _call_chain
    result = func(*args)
  File "/usr/lib/python3.7/urllib/request.py", line 1345, in http_open
    return self.do_open(http.client.HTTPConnection, req)
  File "/usr/lib/python3.7/urllib/request.py", line 1320, in do_open
    r = h.getresponse()
  File "/usr/lib/python3.7/http/client.py", line 1321, in getresponse
    response.begin()
  File "/usr/lib/python3.7/http/client.py", line 296, in begin
    version, status, reason = self._read_status()
  File "/usr/lib/python3.7/http/client.py", line 257, in _read_status
    line = str(self.fp.readline(_MAXLINE + 1), "iso-8859-1")
  File "/usr/lib/python3.7/socket.py", line 589, in readinto
    return self._sock.recv_into(b)
ConnectionResetError: [Errno 104] Connection reset by peer

```

下载数据集的代码如下:

```python
from sklearn.datasets import fetch_mldata
mnist = fetch_mldata('MNIST original')
mnist
```

## 解决方案

下载[mnist-original.mat](https://github.com/amplab/datascience-sp14/raw/master/lab7/mldata/mnist-original.mat)并且保存到 `~/scikit_learn_data/mldata/`(scikit data home dir)下面即可

查找scikit data home dir 的代码:

```python
from sklearn.datasets.base import get_data_home 
print (get_data_home())
```
