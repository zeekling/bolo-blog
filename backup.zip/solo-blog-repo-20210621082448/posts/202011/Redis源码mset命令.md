title: 【Redis源码】mset命令
date: '2020-11-08 18:29:14'
updated: '2021-03-21 13:40:55'
tags: [转载, redis, 源码, 命令]
permalink: /articles/2020/11/08/1604831354258.html
---
## 简介

通过set、setex等命令只能设置单个字符串到数据库，当我们想一次性设置多个字符串时，可以使用mset或msetnx命令来解决。

格式：

```bash
mset key value [key value ...]
msetnx key value [key value ...]
```

## mset 命令

如果某个给定key已经存在，则mset会将原key的value值覆盖，而msetnx是当所有的key都不存在时才可以写入数据库。mset和msetnx底层都是调用的msetGenericCommand函数，不过第2个参数mset的传参为0，msetnx传参为1，msetGenericCommand的函数定义如下：

```cpp
void msetGenericCommand(client *c, int nx)
```

通过命令的格式看出，key和value是成对出现的，加上第一个mset参数，批量设置必须保证命令行参数为奇数。

当nx参数为1时，需要遍历每个key在数据库中是否存在，当有任意一个key存在时，表示参数不合法，会报错退出：

```cpp
if (nx) {
        for (j = 1; j < c->argc; j += 2) {
            if (lookupKeyWrite(c->db,c->argv[j]) != NULL) {
                addReply(c, shared.czero);
                return;
            }
        }
    }
```

当把多个key-value设置入数据库时，同样为了节省内存考虑，需要调用tryObjectEncoding函数将每个value编码。编码完成之后，依次将key-value添加到数据库中。注意mset和msetex不能设置超时时间，所以程序中不需要考虑expire。

```cpp
for (j = 1; j < c->argc; j += 2) {
        c->argv[j+1] = tryObjectEncoding(c->argv[j+1]);
        setKey(c,c->db,c->argv[j],c->argv[j+1]);
        notifyKeyspaceEvent(NOTIFY_STRING,"set",c->argv[j],c->db->id);
    }
```
