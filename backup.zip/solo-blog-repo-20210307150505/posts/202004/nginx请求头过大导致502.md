title: nginx 请求头过大导致502
date: '2020-04-26 22:16:10'
updated: '2020-05-24 12:21:17'
tags: [bolo, 原创]
permalink: /articles/2020/04/26/1587910570502.html
---
![](https://pan.zeekling.cn/KdX_202004253063510299547085179.jpg) 


## 原因
我遇到这个问题是因为最近博客[从solo迁移到bolo](https://www.zeekling.cn/articles/2019/09/07/1587898561235.html) 在迁移完了之后点击链接比较深的时候，会报502错误，但是整个链接的响应速度比较快，于是就看了当时报错的请求参数，如下图所示：

![53711976c2084d0e155b9df0e53c31a1.png](https://img.zeekling.cn/images/2020/04/26/53711976c2084d0e155b9df0e53c31a1.png)

猜想可能是因为cookie 太多太大了，导致nginx报502了，于是就查看了nginx的error.log当时的报错信息如下：
```
2020/04/26 21:57:45 [error] 3152#3152: *5 upstream sent too big header 
while reading response header from upstream, client: 1.80.1.176, server: 
www.zeekling.cn, request: "GET /articles/2020/04/13/1586788757454.html 
HTTP/2.0", upstream: "http://127.0.0.1:8080/articles/2020/04/13/1586788757454.html", 
host: "www.zeekling.cn",referrer:"https://www.zeekling.cn/articles/2019/09/07/
1587898561235.html"
```
果然和自己猜想的一样，于是就在nginx.conf 中增加下面配置：

```
   proxy_buffer_size  128k;
   proxy_buffers   32 32k;
   proxy_busy_buffers_size 128k;
```
重启nginx，刷新页面，问题解决。
