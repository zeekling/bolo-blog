title: Redis 慢查询分析
date: '2020-07-23 16:31:34'
updated: '2020-08-20 23:36:14'
tags: [redis, 转载]
permalink: /articles/2020/07/23/1595493094855.html
---
![183634-1568716594f366.jpg](https://img.zeekling.cn/images/2019/12/08/183634-1568716594f366.jpg)

## 简介

慢查询，顾名思义就是比较慢的查询，但是究竟是哪里慢呢？首先，我们了解一下Redis命令执行的整个过程：

![20200322150028330.jpg](https://pan.zeekling.cn/xnImLXeDtz)

1. 发送命令
2. 命令排队
3. 命令执行
4. 返回结果

在慢查询的定义中，统计比较慢的时间段指的是**命令执行**这个步骤。没有慢查询，并不表示客户端没有超时问题，有可能网络传输有延迟，也有可能排队的命令比较多。

因为Redis中命令执行的排队机制，慢查询会导致其他命令的级联阻塞，所以当客户端出现请求超时的时候，需要检查该时间点是否有慢查询，从而分析出由于慢查询导致的命令级联阻塞。

## 什么是慢查询日志

慢查询日志是Redis服务端在命令执行前后计算每条命令的执行时长，当超过某个阈值是记录下来的日志。日志中记录了慢查询发生的时间，还有执行时长、具体什么命令等信息，它可以用来帮助开发和运维人员定位系统中存在的慢查询。

## 如何获取慢查询日志

可以使用 `slowlog get`命令获取慢查询日志，在 `slowlog get`后面还可以加一个数字，用于指定获取慢查询日志的条数，比如，获取3条慢查询日志：

```
> slowlog get 3
1) 1) (integer) 6107
   2) (integer) 1616398930
   3) (integer) 3109
   4) 1) "config"
      2) "rewrite"
2) 1) (integer) 6106
   2) (integer) 1613701788
   3) (integer) 36004
   4) 1) "flushall"
3) 1) (integer) 6105
   2) (integer) 1608722338
   3) (integer) 20449
   4) 1) "scan"
      2) "0"
      3) "MATCH"
      4) "*comment*"
      5) "COUNT"
      6) "10000"
```

从上面的例子中，可以看出每一条慢查询日志都有4个属性组成：

1. 唯一标识ID
2. 命令执行的时间戳
3. 命令执行时长
4. 执行的命名和参数

## 如何获取慢查询日志的长度

可以使用 `slowlog len`命令获取慢查询日志的长度，比如：

```
> slowlog len
(integer) 121
```

在上例中，当前Redis中有121条慢查询日志。

## 如何清理慢查询日志

可以使用 `slowlog reset`命令清理慢查询日志，比如：

```
> slowlog len
(integer) 121
> slowlog reset
OK
> slowlog len
(integer) 0
```

## 怎么配置慢查询的参数

正如上面提到的，慢查询需要如下两个配置：

命令执行时长的指定阈值。
存放慢查询日志的条数。
Redis对应提供了两个参数：slowlog-log-slower-than和slowlog-max-len，接下来我们详细介绍一下这两个参数。

slowlog-log-slower-than
slowlog-log-slower-than的作用是指定命令执行时长的阈值，执行命令的时长超过这个阈值时就会被记录下来。它的单位是微秒（1秒 = 1000毫秒 = 1000000微秒），默认是10000微秒。如果把slowlog-log-slower-than设置为0，将会记录所有命令到日志中。如果把slowlog-log-slower-than设置小于0，将会不记录任何命令到日志中。

在实际的生产环境中，需要根据Redis并发量来调整该配置。因为Redis采用单线程响应命令，如果命令执行时间在1000微秒以上，那么Redis最多可支撑OPS不到1000，所以对于高并发场景的Redis建议设置为1000微秒。

slowlog-max-len
slowlog-max-len的作用是指定慢查询日志最多存储的条数。实际上，Redis使用了一个列表存放慢查询日志，slowlog-max-len就是这个列表的最大长度。当一个新的命令满足满足慢查询条件时，被插入这个列表中。当慢查询日志列表已经达到最大长度时，最早插入的那条命令将被从列表中移出。比如，slowlog-max-len被设置为10，当有第11条命令插入时，在列表中的第1条命令先被移出，然后再把第11条命令放入列表。

记录慢查询是Redis会对长命令进行截断，不会大量占用大量内存。在实际的生产环境中，为了减缓慢查询被移出的可能和更方便地定位慢查询，建议将慢查询日志的长度调整的大一些。比如可以设置为1000以上。

## 如何进行配置

在Redis中有两个修改配置的方法：

1. 修改Redis配置文件。比如，把slowlog-log-slower-than设置为1000，slowlog-max-len设置为1200：

```
slowlog-log-slower-than 1000
slowlog-max-len 1200
```

2. 使用`config set`命令动态修改。比如，还是把slowlog-log-slower-than设置为1000，slowlog-max-len设置为1200：

```
> config set slowlog-log-slower-than 1000
OK
> config set slowlog-max-len 1200
OK
> config rewrite
OK
```

如果要Redis把配置持久化到本地配置文件，需要执行 `config rewrit`命令。

## 总结

慢查询指的是**命令执行**时长比较长的查询。通过**slowlog get**命令获取慢查询日志；通过**slowlog len**命令获取慢查询日志的长度；通过**slowlog reset**命令清理慢查询日志。通过**slowlog-log-slower-than**配置命令执行时长的阈值；通过**slowlog-max-len**配置慢查询日志最多存储的条数。
