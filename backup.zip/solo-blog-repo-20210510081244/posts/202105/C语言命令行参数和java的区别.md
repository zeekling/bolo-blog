title: C语言命令行参数和java的区别
date: '2021-05-10 07:52:59'
updated: '2021-05-10 07:56:19'
tags: [Java, c语言]
permalink: /articles/2021/05/10/1620604379807.html
---
![image](https://img.zeekling.cn/images/2020/11/22/886c4fc7124ccee5c3fc696866312564.md.jpg)

## 区别

主要区别在与args[0]的值，在C语言当中args[0]是C语言编译出的当前二进制的名称，而在Java当中却是第一个参数的值。

## 代码演示

C语言代码如下：

```cpp
#include <stdio.h>

int main(int argc, char *argv[])
{
    printf("argc=%d, argv=%s", argc, argv[0]);
	return 0;
}
```

使用`gcc args_test.c`编译上面代码并且执行结果如下：

![image.png](https://pan.zeekling.cn/WD2_image.png)

Java代码如下：

```java
package com.zeekling.arg;

public class ArgsTest {

    public static void main(String[] args) {
        System.out.println(args[0]);
    }

}
```

编译之后执行下面命令（代码工程详见：[https://git.zeekling.cn/zeekling/test_java](https://git.zeekling.cn/zeekling/test_java)）：

```bash
java -classpath /home/zeek/project/test_java/target/classes com.zeekling.arg.ArgsTest one two three
```

执行结果如下：

![image.png](https://pan.zeekling.cn/cJJ_image.png)
