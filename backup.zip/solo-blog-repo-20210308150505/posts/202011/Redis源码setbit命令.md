title: 【Redis源码】setbit命令
date: '2020-11-14 19:53:12'
updated: '2021-01-03 21:28:35'
tags: [转载, redis, 命令, 源码]
permalink: /articles/2020/11/14/1605354792615.html
---
setbit命令对key所存储的字符串值，设置指定偏移量上的比特位。

**格式：**

```bash
setbit key offset value
```

返回值： 返回指定偏移量原来存储的位。

![202011141941.png](https://pan.zeekling.cn/doH_2020-11-14_19-41.png)

如图11-1所示，二进制串“abc”在内存中是以011000010110001001100011来表示的，现在字符串第9比特位的值为1，如果想设置此值为0，需要经过以下步骤。

- 判断offset是否合法，一个字节占8位，一个字符串最大长度为512 MB，所以当offset/8大于512 MB时表示offset不合法。
- bit位只可能是0或1，当出现其他字符时不合法，on表示输入的value值。

```cpp
if (on & ~1) {
        addReplyError(c,err);
        return;
    }
```

- 因一个字节占8个比特位，所以修改第offset个比特位，需要先取出第offset/8个字节，赋值为byteval，offset/8赋值为byte。例如，要修改第9个比特位，需要先取出第2个字节。

```cpp
byte = bitoffset >> 3;//一个字节是8位，现在需要除以8，以定位到第byte个字节上
byteval = ((uint8_t*)o->ptr)[byte];//取出第byte个字节
```

- 当取出byteval之后，需要判断原字符串第offset位上的值，供命令的返回值使用。将offset对8取模赋值为bit，bit表示byteval的从低位数第bit位。byteval与bit相与的结果如果大于0表示原比特为1，等于0表示原比特为0。

```cpp
bit = 7 - (bitoffset & 0x7); //offset对8取模
    bitval = byteval & (1 << bit); //1<<bit位表示将1从低位向左移bit位，获取到第bit位
```

- 修改比特位的值。将byteval的从低位数第bit位强制赋值为1。on&0x1的值结果只能为0x1或0x0，将其左移bit位与byteval相或可以得出新的字节的值，o的第byte位赋值为新值便完成了字符串的设置比特位操作。

```cpp
byteval &= ~(1 << bit); //1左移bit位，取反与原值相与，即将原值的低bit位赋值为0
    byteval |= ((on & 0x1) << bit); //on&0x1的值为要修改后的值，左移bit位，与原值相或
    ((uint8_t*)o->ptr)[byte] = byteval;
```
