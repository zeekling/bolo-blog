title: 【Redis源码】mget命令
date: '2020-11-11 23:40:23'
updated: '2021-03-21 13:39:37'
tags: [redis, 转载, 源码]
permalink: /articles/2020/11/11/1605109223498.html
---
通过get命令只能获取单个key的值，如果想获取多个key的值，可以通过mget命令来实现。mget返回所有指定key的值。

**格式：**

```bash
mget key [key …]
```

Redis所有的key-value存储在redisDb的dict中，所以通过一个for循环，就可以依次从数据库中获取到key-value。

```cpp
void mgetCommand(client *c) {
    int j;

    addReplyArrayLen(c,c->argc-1);
    for (j = 1; j < c->argc; j++) {
        robj *o = lookupKeyRead(c->db,c->argv[j]);
        if (o == NULL) {
            addReplyNull(c);
        } else {
            if (o->type != OBJ_STRING) {
                addReplyNull(c);
            } else {
                addReplyBulk(c,o);
            }
        }
    }
}
```
