title: bolo-fantastic皮肤整改
date: '2020-09-04 00:29:35'
updated: '2020-11-01 15:09:13'
tags: [原创, 博客]
permalink: /articles/2020/09/04/1599150574976.html
---
![cd836d1451f49e5071416269580b7383.jpg](https://img.zeekling.cn/images/2020/08/23/cd836d1451f49e5071416269580b7383.jpg)

## 简介

整改皮肤bolo-fantastic的原因如下：

- bolo-fantastic 挺好看的，至少我挺喜欢的。
- 存在一些看起来不那么完美的地方。
- 我有病(可能是最主要的原因)。

于是就有了整改。

## 整改

项目地址：[zeekling/bolo-fantastic](https://git.zeekling.cn/zeekling/bolo-fantastic "此项目是本人对bolo-fantastic进行了一些改造，包括样式和seo两方面。")

项目演示地址：[小令童鞋](https://www.zeekling.cn/?skin=bolo-fantastic)

![202009040026.png](https://pan.zeekling.cn/u6D_2020-09-04_00-26.png)

网站底部：

![202009040027.png](https://pan.zeekling.cn/A2M_2020-09-04_00-27.png)
