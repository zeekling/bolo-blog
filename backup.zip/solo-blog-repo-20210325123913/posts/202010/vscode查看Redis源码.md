title: vscode 查看Redis源码
date: '2020-10-20 20:53:02'
updated: '2021-03-21 13:42:20'
tags: [源码, redis, 原创, vscode]
permalink: /articles/2020/10/20/1603198382711.html
---
![镇楼](https://img.zeekling.cn/images/2020/10/06/597ac3c92b74b738e1adb1a9e795b5c1.jpg)

## 简介

最近在学习Redis源码，主要是目前负责华为产品[FusionInsight HD](https://support.huawei.com/enterprise/zh/cloud-computing/fusioninsight-hd-pid-21110924)中Redis组件的相关事务，不得不学习Redis源码。本文主要讲述的是怎么通过vscode查看Redis的源码(Linux平台下面).

## 配置

在项目下面增加文件夹 `.vscode`，并且新建文件：`launch.json` 、`tasks.json`、 `c_cpp_properties.json`，并且在文件中添加下面内容：

launch.json:

```json
{
    "version": "0.2.0",
    "configurations": [
  
        {
            "name": "build",
            "type": "cppdbg",
            "request": "launch",
            "program": "${workspaceFolder}/src/redis-server",
            "args": [
                "redis.conf"
            ],
            "stopAtEntry": true,
            "cwd": "${workspaceFolder}",
            "environment": [],
            "externalConsole": false,
            "MIMode": "gdb",
            "preLaunchTask": "shell"
        }
    ]
}
```

tasks.json:

```json
{
    "version": "2.0.0",
    "tasks": [
        {
            "label": "shell",
            "type": "shell",
            "command": "/usr/bin/make"
        }
    ]
}
```

c_cpp_properties.json

```json
{
    "configurations": [
        {
            "name": "Linux",
            "includePath": [
                "${workspaceFolder}/**"
            ],
            "defines": [],
            "compilerPath": "/usr/bin/clang",
            "cStandard": "c11",
            "cppStandard": "c++14",
            "intelliSenseMode": "clang-x64"
        }
    ],
    "version": 4
}
```

## 运行

使用快捷键F5进行编译调试。
