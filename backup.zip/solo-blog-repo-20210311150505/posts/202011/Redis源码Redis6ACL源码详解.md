title: 【Redis源码】Redis 6 ACL源码详解
date: '2020-11-22 23:49:38'
updated: '2021-01-03 21:27:36'
tags: [原创, redis, 新特性, 源码]
permalink: /articles/2020/11/22/1606060178482.html
---
## 简介

本文主要是讲解Redis 6的ACL的实现原理。基本使用详见：[Redis 6.0新特性——ACLs](/articles/2020/11/22/1606048977051.html)，以及[Redis启动过程分析](https://www.zeekling.cn/articles/2020/09/25/1601041404734.html)。

## 启动初始化

### 初始化默认用户

ACL子模块在[Redis启动过程中初始化](https://www.zeekling.cn/articles/2020/09/25/1601041404734.html)，下面代码主要是初始化ACL的结构：

```cpp
/* 
 * 初始化ACL子系统
 * */
void ACLInit(void) {
    Users = raxNew(); // 初始化用户信息
    UsersToLoad = listCreate();
    ACLLog = listCreate();
    ACLInitDefaultUser();
    server.requirepass = NULL; /* Only used for backward compatibility. */
}
```

ACLInitDefaultUser函数主要是初始化默认用户，在Redis 6当中默认用户的权限就相当于操作系统的管理员一样，拥有很大的权限，要限制远程使用默认用户连接。

```cpp
/* 初始化默认用户 */
void ACLInitDefaultUser(void) {
    DefaultUser = ACLCreateUser("default",7);
    ACLSetUser(DefaultUser,"+@all",-1); // 默认用户赋予所有命令的权限
    ACLSetUser(DefaultUser,"~*",-1);// 可以操作任何key
    ACLSetUser(DefaultUser,"on",-1);// 默认开启
    ACLSetUser(DefaultUser,"nopass",-1); // 默认不需要密码
}
```

### 加载ACL用户信息

ACL数据结构初始化完成之后，通过函数 `ACLLoadUsersAtStartup`加载Redis配置里面的ACL用户信息。Redis ACL配置信息主要有两种方式：

- 在redis.conf文件中通过user 配置项配置的ACL信息。比如：`user worker +@list +@connection ~jobs:* on >ffa9203c493aa99`
- 在`redis.conf`中配置`aclfile`所配置的文件中。格式如下图所示：

![图片](https://pan.zeekling.cn/fWh_image.png)

#### 通过user方式

通过加载redis.conf配置文件中读取user配置项加载ACL信息。

```cpp
int ACLLoadConfiguredUsers(void) {
    listIter li;
    listNode *ln;
    listRewind(UsersToLoad,&li);
    while ((ln = listNext(&li)) != NULL) {
        sds *aclrules = listNodeValue(ln);
        sds username = aclrules[0];

        // 检查ACL用户名当中是否存在空格
        if (ACLStringHasSpaces(aclrules[0],sdslen(aclrules[0]))) {
            serverLog(LL_WARNING,"Spaces not allowed in ACL usernames");
            return C_ERR;
        }
        // 创建ACL用户
        user *u = ACLCreateUser(username,sdslen(username));
        if (!u) {
            u = ACLGetUserByName(username,sdslen(username));
            serverAssert(u != NULL);
            ACLSetUser(u,"reset",-1);
        }

        /* Load every rule defined for this user. */
        for (int j = 1; aclrules[j]; j++) {
            // 添加当前用户的所有属性
            if (ACLSetUser(u,aclrules[j],sdslen(aclrules[j])) != C_OK) {
                char *errmsg = ACLSetUserStringError();
                serverLog(LL_WARNING,"Error loading ACL rule '%s' for "
                                     "the user named '%s': %s",
                          aclrules[j],aclrules[0],errmsg);
                return C_ERR;
            }
        }

        /* Having a disabled user in the configuration may be an error,
         * warn about it without returning any error to the caller.
         * 用户没有开启的时候打印到日志里面
         * */
        if (u->flags & USER_FLAG_DISABLED) {
            serverLog(LL_NOTICE, "The user '%s' is disabled (there is no "
                                 "'on' modifier in the user description). Make "
                                 "sure this is not a configuration error.",
                      aclrules[0]);
        }
    }
    return C_OK;
}
```

#### 通过文件方式

`ACLLoadFromFile`函数就是从redis.conf配置的 `aclfile`所在的文件当中读取ACL配置信息。

## ACL 控制

ACL控制主要是在从命令表中获取命令之后判断当前登录的用户是否对当前执行的命令是否有权限。判断的函数为：

```cpp
int ACLCheckCommandPerm(client *c, int *keyidxptr) 
```

具体判断是否存在权限的函数为ACLGetUserCommandBit，主要实现如代码，其中id表示当前命令所对应的id。

```cpp
int ACLGetUserCommandBit(user *u, unsigned long id) {
    uint64_t word, bit;
    // 计算命令在allowed_commands当中对应的bit位
    if (ACLGetCommandBitCoordinates(id,&word,&bit) == C_ERR) return 0;
    return (u->allowed_commands[word] & bit) != 0;
}
```
