title: kali rolling 跟新后连不上wifi修复
date: '2020-09-26 12:06:48'
updated: '2021-03-21 13:54:59'
tags: [linux, 原创, kali, 网卡]
permalink: /articles/2020/09/26/1601093208586.html
---
![776f23086ee40f88f350b923b803e266.jpg](https://img.zeekling.cn/images/2020/08/23/776f23086ee40f88f350b923b803e266.jpg)

## 简介

本人使用kali linux也有五六年了吧，就在昨晚执行了下面升级命令之后就发生了惨案：重启电脑之后上不了无线网。

```bash
sudo apt upgrade --fix-missing
```

我的电脑比较老，网卡还是 `BCM43142`类型的于是就开始找原因。

## 原因分析

执行命令查看linux内核版本

```bash
 zeek@kali  ~  uname -r
5.8.0-kali1-amd64

```

鉴于这个网卡驱动依赖linux头文件，于是查看系统中linux头文件，执行命令：

```bash
sudo dpkg -l | grep linux-head
```

执行结果如下：

![202009261055.png](https://pan.zeekling.cn/k06_2020-09-26_10-55.png)

那么问题就已经基本确定了：内核头文件没有升级导致网卡驱动使用不了。

> 此网卡驱动依赖内核头文件参考：[kali rolling linux 安装BCM43142网卡驱动](https://www.zeekling.cn/articles/2020/09/26/1601091635148.html)

## 解决问题

问题既然已经找到，问题就变成升级内核头文件了。

### 升级内核头文件

执行下面命令升级内核头文件，执行下面命令：

```bash
sudo apt install linux-headers-`uname -r`
```

### 重启电脑

升级完内核头文件之后，重启电脑生效：
